

# Dashboard de Gouvernance Technologique

Ce projet est un tableau de bord interactif pour visualiser et piloter la gouvernance technologique d'une organisation. Il a été conçu pour offrir une vue claire et actionnable du paysage technologique, en s'inspirant des concepts de "Tech Radar" et de tableaux de bord DevOps.

## Fonctionnalités

Le tableau de bord est organisé en trois vues principales :

### 1. Aperçu
- **Introduction** : Présente l'objectif et les différentes sections de l'outil.
- **Validation des Données** : Affiche un message d'erreur clair et visible si des incohérences sont détectées dans les fichiers de données (ex: un `radar_id` invalide ou un code de catégorie non conforme).
- **Graphiques Interactifs** :
    - **Statut des Usages Technologiques** : Un graphique en anneau (donut) montrant la répartition des technologies par statut. Cliquer sur une section du graphique filtre le "Tableau de Bord". Ce graphique est également filtrable par squad.
    - **Taux d'Adoption des Pratiques** : Un graphique à barres visualisant le niveau d'adoption des pratiques de développement clés.
    - **Respect des règles de l'Orchestrateur** : Un graphique à barres visualisant le niveau de conformité aux règles de l'orchestrateur.

### 2. Tech Radar
- **Vue Stratégique** : Représentation visuelle de la stratégie technologique, classant les technologies, outils, plateformes et langages en quatre anneaux (Référence, Émergent, Évaluation, Confiné).
- **Interactivité** :
    - **Filtres** : Filtrez les éléments du radar par anneau, et filtrez le tableau de détails par anneau, quadrant, type et responsable.
    - **Détails** : Cliquez sur un élément (blip) sur le radar pour afficher une modale avec sa justification, le responsable et un lien externe si disponible.
    - **Tableau Récapitulatif** : Une liste détaillée et filtrable de toutes les technologies présentes sur le radar.

### 3. Tableau de Bord
- **Vue Opérationnelle** : Fournit une analyse détaillée de l'état actuel des technologies et pratiques sur le terrain.
- **Validation des Données** : Affiche les mêmes messages d'erreur que dans les autres vues si des incohérences sont détectées.
- **Matrices de Conformité** :
    - **Matrice d'Adoption des Pratiques** : Un tableau détaillé montrant quelle équipe a adopté quelle pratique de développement.
    - **Respect des règles de l'Orchestrateur** : Un tableau similaire montrant la conformité aux règles de déploiement.
- **Catalogue des Usages Technologiques** : Un inventaire complet des technologies utilisées par chaque squad et projet. Il est possible de filtrer ce catalogue par squad, statut, et autres dimensions.

## Structure du Code et des Données

Le projet est une application web front-end statique, entièrement pilotée par des fichiers de configuration et de données au format CSV.

### Arborescence du Code

-   `index.html`: La structure principale de la page web.
-   `index.css`: Styles CSS pour l'ensemble de l'application.
-   `scripts/`: Contient tout le code JavaScript modulaire.
    -   `app.js`: **Point d'entrée principal.** Gère la navigation entre les vues, l'initialisation globale et la coordination entre les modules.
    -   `data.js`: **Module de gestion des données.** Responsable du chargement, du parsing, de la validation croisée et de l'enrichissement des données à partir des fichiers CSV.
    -   `apercu.js`: Gère toute la logique de la vue "Aperçu", y compris la création et la mise à jour des graphiques.
    -   `radar.js`: Gère la vue "Tech Radar", incluant le dessin du radar SVG, la gestion des "blips" (points), et la logique des filtres et du tableau de détails.
    -   `dashboard.js`: Gère la vue "Tableau de Bord", qui inclut les matrices de conformité, le catalogue des usages et la navigation par onglets.
    -   `sortable-table.js`: Module générique et réutilisable pour créer des tableaux HTML triables.
-   `conf/`: Contient les fichiers CSV de **configuration** qui définissent les référentiels (ex: la liste des quadrants, des statuts).
-   `data/`: Contient les fichiers CSV de **données brutes** (ex: les technologies, les projets, leurs usages).
-   `README.md`: Ce fichier.

### Configuration de la Source de Données
Le projet peut charger ses données depuis des fichiers CSV locaux (comportement par défaut) ou être adapté pour interroger une base de données via une API. La configuration se fait dans le fichier `conf/app_config.json`.

```json
{
  "type": "csv"
}
```
- **`type`**: Définit la source de données.
  - `"csv"`: (Défaut) Charge les données depuis les fichiers CSV dans les répertoires `conf/` et `data/`.
  - `"database"`: (Futur) Tente de charger les données depuis une source de données distante. **Nécessite un backend API non fourni dans ce projet.**

### Les Données : `conf/` et `data/`
Le tableau de bord est entièrement piloté par des fichiers CSV, répartis dans deux répertoires.

---

### `conf/` : Fichiers de Mapping (Référentiels)
Ces fichiers définissent les valeurs autorisées pour les catégories et enrichissent les données brutes.

- **`conf/rings_data.csv`**: Définit les anneaux du radar (Adopt, Trial, etc.).
- **`conf/quadrants_data.csv`**: Définit les quadrants du radar (Techniques, Outils, etc.).
- **`conf/types_data.csv`**: Définit les types fonctionnels des technologies et pratiques.
- **`conf/statuses_data.csv`**: Définit les statuts d'usage des technologies (Référence, Confiné, etc.).

---

### `data/` : Fichiers de Données
Ces fichiers contiennent les enregistrements qui sont enrichis grâce aux fichiers de mapping.

- **`data/projects_data.csv`**: Définit la liste des projets.
- **`data/responsables_data.csv`**: Définit les équipes ou individus responsables.
- **`data/orchestrateur_types_data.csv`**: Définit les types de règles de l'orchestrateur.

- **`data/radar_data.csv` (Fichier Maître)**
  - `id`: **(Clé primaire)** Identifiant unique.
  - `name`: Nom lisible de l'élément.
  - `quadrant_code`: **(Clé étrangère)** Doit correspondre à un `code` de `conf/quadrants_data.csv`.
  - `ring_code`: **(Clé étrangère)** Doit correspondre à un `code` de `conf/rings_data.csv`.
  - `type_code`: **(Clé étrangère)** Doit correspondre à un `code` de `conf/types_data.csv`.
  - `responsable_codes`: **(Clé étrangère)** Un ou plusieurs `code`s de `data/responsables_data.csv`, séparés par un point-virgule (`;`).
  - `justification`: Texte explicatif.
  - `link`: (Optionnel) URL externe.

- **`data/technologies_data.csv` (Catalogue des Usages)**
  - `radar_id`: **(Clé étrangère)** Doit correspondre à un `id` de `data/radar_data.csv`.
  - `project_code`: **(Clé étrangère)** Doit correspondre à un `code` de `data/projects_data.csv`.
  - `squad`: Nom de l'équipe.
  - `status_code`: **(Clé étrangère)** Doit correspondre à un `code` de `conf/statuses_data.csv`.

- **`data/pratiques_data.csv` (Matrice d'Adoption des Pratiques)**
  - `radar_id`: **(Clé étrangère)** Doit correspondre à un `id` de `data/radar_data.csv`.
  - `project_code`: **(Clé étrangère)** Doit correspondre à un `code` de `data/projects_data.csv`.
  - `squad`: Nom de l'équipe.
  - `status`: Statut d'adoption (`Oui`, `Partiel`, `Non`).

- **`data/orchestrateur_data.csv` (Matrice de Conformité des Règles)**
  - `id`, `name`: Description de la règle.
  - `type_code`: **(Clé étrangère)** Doit correspondre à un `code` de `data/orchestrateur_types_data.csv`.
  - `project_code`: **(Clé étrangère)** Doit correspondre à un `code` de `data/projects_data.csv`.
  - `squad`: Nom de l'équipe.
  - `status`: Statut de conformité (`Oui`, `Partiel`, `Non`).

## Comment Lancer

**IMPORTANT :** Cette application charge des fichiers locaux et doit être exécutée via un serveur web local pour fonctionner correctement.

### Option 1 : Avec Visual Studio Code (Recommandé)
1. Installez l'extension **"Live Server"**.
2. Faites un clic droit sur le fichier `index.html` et choisissez **"Open with Live Server"**.

### Option 2 : Avec Python
1. Ouvrez un terminal dans le répertoire du projet.
2. Lancez `python -m http.server` (pour Python 3) ou `python -m SimpleHTTPServer` (pour Python 2).
3. Ouvrez votre navigateur à l'adresse `http://localhost:8000`.
