/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @fileoverview Gère la logique et le rendu pour la vue "Tech Radar".
 * Comprend le dessin du radar SVG, la gestion des "blips" (points),
 * la modale de détails, les filtres et le tableau de détails des technologies.
 */
import { initSortableTable } from './sortable-table.js';

const quadrantConfig = {
    'techniques': { startAngle: 180, endAngle: 270, name: 'Techniques' },
    'tools':      { startAngle: 270, endAngle: 360, name: 'Outils' },
    'platforms':  { startAngle: 90, endAngle: 180, name: 'Plateformes' },
    'lang_fw':    { startAngle: 0, endAngle: 90, name: 'Langages & FW' },
};

const quadrantDescriptions = {
    'techniques': "Méthodes, pratiques et approches de développement que nous utilisons pour construire nos produits.",
    'tools': "Outils, librairies et services qui supportent notre cycle de vie de développement logiciel.",
    'platforms': "Plateformes et infrastructure sur lesquelles nous construisons et déployons nos applications.",
    'lang_fw': "Langages de programmation et frameworks que nous utilisons pour développer nos solutions."
};

const ringConfig = [
    { radius: 0.45, code: 'Adopt' }, { radius: 0.70, code: 'Trial' },
    { radius: 0.85, code: 'Assess' }, { radius: 1.0, code: 'Hold' }
];
const ringColors = {
    'Adopt': 'ring-Adopt', 'Trial': 'ring-Trial',
    'Assess': 'ring-Assess', 'Hold': 'ring-Hold'
};

let lastFocusedElement = null; // For accessibility

/**
 * Crée une version "debounced" d'une fonction qui retarde son exécution.
 * @param {Function} func - La fonction à "debouncer".
 * @param {number} wait - Le délai en millisecondes.
 * @returns {Function} La nouvelle fonction "debounced".
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Rend les colonnes d'un tableau redimensionnables par glisser-déposer.
 * @param {HTMLTableElement} table - L'élément de la table à rendre redimensionnable.
 */
function makeTableResizable(table) {
    const headers = table.querySelectorAll('th');
    headers.forEach(header => {
        const resizer = document.createElement('div');
        resizer.className = 'resizer';
        header.appendChild(resizer);
        resizer.addEventListener('mousedown', (e) => {
            e.preventDefault();
            const startX = e.pageX;
            const startWidth = header.offsetWidth;
            const onMouseMove = (mouseMoveEvent) => {
                const newWidth = startWidth + (mouseMoveEvent.pageX - startX);
                if (newWidth > 50) { header.style.width = `${newWidth}px`; }
            };
            const onMouseUp = () => {
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
            };
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        });
    });
}

/**
 * Exporte des données au format CSV et déclenche le téléchargement.
 * @param {string} filename - Le nom du fichier à télécharger.
 * @param {Array<Object>} dataToExport - Le tableau d'objets à exporter.
 * @param {Object.<string, string>} headers - Un objet mappant les clés de données aux en-têtes de colonnes CSV.
 */
function exportToCsv(filename, dataToExport, headers) {
    if (!dataToExport || dataToExport.length === 0) { return; }
    const columnKeys = headers ? Object.keys(headers) : Object.keys(dataToExport[0]);
    const headerValues = headers ? Object.values(headers) : columnKeys;
    const csvRows = ['\uFEFF' + headerValues.join(',')];
    for (const row of dataToExport) {
        const values = columnKeys.map(key => {
            let cell = row[key] === null || row[key] === undefined ? '' : String(row[key]);
            cell = cell.replace(/"/g, '""');
            if (cell.search(/("|,|\n)/g) >= 0) { cell = `"${cell}"`; }
            return cell;
        });
        csvRows.push(values.join(','));
    }
    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

/**
 * Génère le SVG du radar et y place les "blips" (points technologiques).
 * @param {Array<Object>} radarData - Les données des technologies à afficher.
 * @param {HTMLElement} container - L'élément conteneur pour le radar.
 * @param {number} radarSize - La taille (largeur et hauteur) du radar en pixels.
 * @param {Array<Object>} ringsData - Les données de configuration des anneaux.
 */
function renderRadar(radarData, container, radarSize, ringsData) {
    if (!radarSize || radarSize <= 0) {
        return;
    }
    
    container.innerHTML = '';
    const svgNS = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute('width', radarSize);
    svg.setAttribute('height', radarSize);
    svg.setAttribute('viewBox', `0 0 ${radarSize} ${radarSize}`);
    const center = radarSize / 2;
    const lineX = document.createElementNS(svgNS, 'line');
    lineX.setAttribute('x1', 0); lineX.setAttribute('y1', center);
    lineX.setAttribute('x2', radarSize); lineX.setAttribute('y2', center);
    lineX.setAttribute('class', 'radar-quadrant-line');
    svg.appendChild(lineX);
    const lineY = document.createElementNS(svgNS, 'line');
    lineY.setAttribute('x1', center); lineY.setAttribute('y1', 0);
    lineY.setAttribute('x2', center); lineY.setAttribute('y2', radarSize);
    lineY.setAttribute('class', 'radar-quadrant-line');
    svg.appendChild(lineY);
    let prevRingRadiusPx = 0;
    ringConfig.forEach(ringGeom => {
        const ringData = ringsData.find(r => r.code === ringGeom.code);
        if (!ringData) return;
        const ringRadiusPx = ringGeom.radius * center;
        const circle = document.createElementNS(svgNS, 'circle');
        circle.setAttribute('cx', center);
        circle.setAttribute('cy', center);
        circle.setAttribute('r', ringRadiusPx);
        circle.setAttribute('class', 'radar-ring');
        svg.appendChild(circle);
        const labelRadiusPx = (ringRadiusPx + prevRingRadiusPx) / 2;
        const label = document.createElementNS(svgNS, 'text');
        label.setAttribute('x', center);
        // Positionne le titre de l'anneau au milieu de sa zone radiale.
        label.setAttribute('y', center - labelRadiusPx - 5);
        label.setAttribute('class', 'radar-ring-label');
        label.textContent = ringData.name.toUpperCase();
        svg.appendChild(label);
        prevRingRadiusPx = ringRadiusPx;
    });
    container.appendChild(svg);
    const segmentData = {};
    radarData.forEach(item => {
        const segmentId = `${item.quadrant_code}-${item.ring_code}`;
        if (!segmentData[segmentId]) { segmentData[segmentId] = []; }
        segmentData[segmentId].push(item);
    });
    for (const segmentId in segmentData) {
        const items = segmentData[segmentId];
        const [quadrantCode, ringCode] = segmentId.split('-');
        const q = quadrantConfig[quadrantCode];
        const r_info = ringConfig.find(r => r.code === ringCode);
        if (!q || !r_info) continue;
        const r_index = ringConfig.indexOf(r_info);
        const r_outer = r_info.radius;
        const r_inner = r_index > 0 ? ringConfig[r_index - 1].radius : 0;
        
        let effectiveStartAngle = q.startAngle;
        let effectiveEndAngle = q.endAngle;

        // CRÉATION D'UNE "ZONE DE SÉCURITÉ" :
        // Pour éviter que les points ne se superposent aux titres des anneaux (qui sont affichés verticalement),
        // on réduit la plage angulaire disponible pour les quadrants du haut.
        // Cela "pousse" les points sur les côtés, laissant le centre vertical libre.
        if (q.startAngle === 0 && q.endAngle === 90) { // Top-right
            effectiveStartAngle = 10;
            effectiveEndAngle = 80;
        }
        if (q.startAngle === 90 && q.endAngle === 180) { // Top-left
            effectiveStartAngle = 100;
            effectiveEndAngle = 170;
        }

        const segmentAngle = effectiveEndAngle - effectiveStartAngle;
        const segmentRadius = r_outer - r_inner;

        items.forEach((item, i) => {
            // ALGORITHME DE DISPERSION DES POINTS :
            // Pour éviter que tous les points d'un même segment ne soient alignés,
            // on introduit une variation (jitter) sur leur angle et leur rayon.
            const angleOffset = (segmentAngle / (items.length || 1)) * (i + 0.5); // Répartit uniformément les angles.
            const radiusOffset = segmentRadius * ((i % 3 + 1) / 3.5); // Crée une variation de rayon cyclique pour former des "vagues".
            
            const angleDeg = effectiveStartAngle + angleOffset;
            const radius = r_inner + radiusOffset;
            
            // CONVERSION POLAIRE -> CARTÉSIEN :
            // On convertit les coordonnées polaires (angle, rayon) en coordonnées cartésiennes (x, y)
            // pour le positionnement CSS. Le système de coordonnées du radar est inversé verticalement (0° est à droite).
            const angleRad = angleDeg * Math.PI / 180;
            const x = 0.5 + (radius * Math.cos(angleRad) * 0.5);
            const y = 0.5 - (radius * Math.sin(angleRad) * 0.5);
            
            const blip = document.createElement('div');
            const ringClass = ringColors[r_info.code] || '';
            blip.className = `blip ${ringClass}`;
            blip.style.left = `calc(${x * 100}% - 14px)`;
            blip.style.top = `calc(${y * 100}% - 14px)`;
            blip.textContent = item.displayId;
            blip.setAttribute('title', item.name);
            blip.dataset.techId = item.id;
            blip.tabIndex = 0; // Make it focusable
            blip.setAttribute('role', 'button');
            blip.setAttribute('aria-label', `Détails pour ${item.name}`);

            const openModal = (event) => {
                lastFocusedElement = event.currentTarget;
                showModal(item);
            };

            blip.addEventListener('click', openModal);
            blip.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    openModal(e);
                }
            });

            container.appendChild(blip);
        });
    }
}

/**
 * Masque la modale de détails.
 */
function hideModal() {
    const modal = document.getElementById('radar-modal');
    modal.classList.add('hidden');
    if (lastFocusedElement) {
        lastFocusedElement.focus();
        lastFocusedElement = null;
    }
    document.removeEventListener('keydown', handleModalKeydown);
}

/**
 * Gère les événements clavier pour la modale (fermeture avec 'Escape').
 * @param {KeyboardEvent} event - L'événement clavier.
 */
function handleModalKeydown(event) {
    if (event.key === 'Escape') {
        hideModal();
    }
}

/**
 * Affiche la modale avec les détails d'un item technologique.
 * @param {object} item - L'objet de données de l'item à afficher.
 */
function showModal(item) {
    const modal = document.getElementById('radar-modal');
    const modalCloseButton = document.getElementById('modal-close');
    const ringIcons = { 'Adopt': '✅', 'Trial': '💡', 'Assess': '❓', 'Hold': '🚨' };
    const ringHeaderColors = { 
        'Adopt': 'bg-green-100', 'Trial': 'bg-blue-100', 
        'Assess': 'bg-yellow-100', 'Hold': 'bg-red-100' 
    };
    document.getElementById('modal-header').className = `p-5 rounded-t-2xl ${ringHeaderColors[item.ring_code] || 'bg-slate-100'}`;
    document.getElementById('modal-icon').textContent = ringIcons[item.ring_code] || '⭐';
    document.getElementById('modal-title').textContent = item.name;
    const tagsContainer = document.getElementById('modal-tags');
    tagsContainer.innerHTML = '';
    const tagClasses = 'px-3 py-1 text-xs font-semibold rounded-full';
    const ringTagColors = { 
        'Adopt': 'bg-green-200 text-green-800', 'Trial': 'bg-blue-200 text-blue-800', 
        'Assess': 'bg-yellow-200 text-yellow-800', 'Hold': 'bg-red-200 text-red-800' 
    };
    [
        { text: item.ring, color: ringTagColors[item.ring_code] || 'bg-slate-200 text-slate-800' },
        { text: item.quadrant, color: 'bg-slate-200 text-slate-800' },
        { text: item.type, color: 'bg-slate-200 text-slate-800' }
    ].forEach(tagInfo => {
        const span = document.createElement('span');
        span.className = `${tagClasses} ${tagInfo.color}`;
        span.textContent = tagInfo.text;
        tagsContainer.appendChild(span);
    });

    document.getElementById('modal-justification').textContent = item.justification;
    const linkContainer = document.getElementById('modal-link-container');
    linkContainer.innerHTML = '';
    if (item.link) {
        const link = document.createElement('a');
        link.href = item.link;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.className = 'inline-flex items-center font-semibold text-sky-600 hover:text-sky-800 hover:underline';
        link.innerHTML = `En savoir plus <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>`;
        linkContainer.appendChild(link);
    }
    modal.classList.remove('hidden');
    modalCloseButton.focus(); // Focus management
    document.addEventListener('keydown', handleModalKeydown);
}

/**
 * Traite les données brutes du radar pour y ajouter un ID d'affichage numérique.
 * @param {Array<Object>} radarData - Les données brutes du radar.
 * @returns {Array<Object>} Les données traitées avec un `displayId`.
 */
function processRadarData(radarData) {
    const quadrantOrder = ['techniques', 'tools', 'platforms', 'lang_fw'];
    // Trie les données pour assurer que les numéros des points sont stables et cohérents
    // peu importe l'ordre des lignes dans le fichier CSV.
    const sortedData = [...radarData].sort((a, b) => {
        const quadAIndex = quadrantOrder.indexOf(a.quadrant_code);
        const quadBIndex = quadrantOrder.indexOf(b.quadrant_code);
        if (quadAIndex !== quadBIndex) { return quadAIndex - quadBIndex; }
        return a.name.localeCompare(b.name);
    });
    return sortedData.map((item, index) => ({ ...item, displayId: index + 1 }));
}

/**
 * Met en place les écouteurs d'événements pour le surlignage au survol.
 */
function setupHighlighting() {
    const view = document.getElementById('radar-view');
    if (!view || view.dataset.highlightingAttached) return;
    const highlightElements = (techId, state) => {
        document.querySelectorAll(`[data-tech-id="${techId}"]`).forEach(el => {
            el.classList.toggle('highlight', state);
        });
    };
    view.addEventListener('mouseover', (e) => {
        const target = e.target.closest('[data-tech-id]');
        if (target) { highlightElements(target.dataset.techId, true); }
    });
    view.addEventListener('mouseout', (e) => {
        const target = e.target.closest('[data-tech-id]');
        if (target) { highlightElements(target.dataset.techId, false); }
    });
    view.dataset.highlightingAttached = 'true';
}

/**
 * Génère la légende des anneaux du radar.
 * @param {Array<Object>} ringsData - Les données de configuration des anneaux.
 */
function renderRingLegend(ringsData) {
    const legendContainer = document.getElementById('radar-ring-legend');
    if (!legendContainer) return;
    legendContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();
    ringsData.forEach(ring => {
        const ringClass = ringColors[ring.code] || '';
        const card = document.createElement('div');
        card.className = `ring-legend-card ${ringClass}`;
        
        const title = document.createElement('h3');
        title.className = 'font-bold text-slate-800 mb-1';
        title.textContent = ring.name;
        
        const description = document.createElement('p');
        description.className = 'text-sm text-slate-600';
        description.textContent = ring.description || '';
        
        card.append(title, description);
        fragment.appendChild(card);
    });
    legendContainer.appendChild(fragment);
}

/**
 * Génère la légende des quadrants du radar.
 * @param {Array<Object>} quadrantsData - Les données de configuration des quadrants.
 */
function renderQuadrantLegend(quadrantsData) {
    const legendContainer = document.getElementById('radar-quadrant-legend');
    if (!legendContainer) return;
    legendContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();
    quadrantsData.forEach(quadrant => {
        const descriptionText = quadrantDescriptions[quadrant.code] || 'Aucune description disponible.';
        const card = document.createElement('div');
        card.className = `bg-white p-4 rounded-lg shadow-sm`;

        const title = document.createElement('h3');
        title.className = 'font-bold text-slate-800 mb-1';
        title.textContent = quadrant.name;

        const description = document.createElement('p');
        description.className = 'text-sm text-slate-600';
        description.textContent = descriptionText;
        
        card.append(title, description);
        fragment.appendChild(card);
    });
    legendContainer.appendChild(fragment);
}

/**
 * Point d'entrée pour initialiser la vue "Tech Radar".
 * @param {object} data - L'objet de données global de l'application.
 */
export function initRadar(data) {
    const { radarData, ringsData, typesData, allSquads, technologiesData, pratiquesData, quadrantsData, projectsData } = data;
    
    const wrapper = document.getElementById('radar-wrapper');
    const container = document.getElementById('radar-container');
    const modal = document.getElementById('radar-modal');
    const modalClose = document.getElementById('modal-close');
    const searchInput = document.getElementById('radar-search');
    const typeFilter = document.getElementById('radar-type-filter');
    const ringFilter = document.getElementById('radar-ring-filter');
    const squadFilter = document.getElementById('radar-squad-filter');
    const quadrantFilter = document.getElementById('radar-quadrant-filter');
    const projectFilter = document.getElementById('radar-project-filter');
    const exportBtn = document.getElementById('export-radar-btn');
    const tableEl = document.getElementById('radar-details-table');

    if (!wrapper || !container || !modal || !modalClose || !tableEl || !searchInput) {
        console.error("[RADAR] A critical element for the radar view is missing from the DOM.");
        return;
    }

    const processedRadarData = processRadarData(radarData);
    let currentlyDisplayedData = [];

    if (typeFilter && typeFilter.options.length <= 1) { typesData.forEach(t => typeFilter.add(new Option(t.name, t.name))); }
    if (ringFilter && ringFilter.options.length <= 1) { ringsData.forEach(r => ringFilter.add(new Option(r.name, r.name))); }
    if (squadFilter && squadFilter.options.length <= 1) { allSquads.forEach(s => squadFilter.add(new Option(s, s))); }
    if (quadrantFilter && quadrantFilter.options.length <= 1) { quadrantsData.forEach(q => quadrantFilter.add(new Option(q.name, q.name))); }
    if (projectFilter && projectFilter.options.length <= 1) { projectsData.forEach(p => projectFilter.add(new Option(p.name, p.code))); }


    function renderTableRow(item) {
        const row = document.createElement('tr');
        row.className = 'hover:bg-slate-50';
        row.dataset.techId = item.id;
        const ringTagColors = { 'Adopt': 'bg-green-100 text-green-800', 'Trial': 'bg-blue-100 text-blue-800', 'Assess': 'bg-yellow-100 text-yellow-800', 'Hold': 'bg-red-100 text-red-800' };
        const ringColorClass = ringTagColors[item.ring_code] || 'bg-slate-100 text-slate-800';
        let linkHtml = 'N/A';
        if (item.link) { linkHtml = `<a href="${item.link}" target="_blank" rel="noopener noreferrer" class="text-sky-600 hover:underline">Lien</a>`; }
        row.innerHTML = `<td class="px-6 py-4 text-slate-600 text-sm">${item.type || 'N/A'}</td><td class="px-6 py-4 font-medium text-slate-900">${item.name}</td><td class="px-6 py-4 text-slate-600">${item.quadrant}</td><td class="px-6 py-4"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${ringColorClass}">${item.ring}</span></td><td class="px-6 py-4 text-slate-600 text-sm">${item.responsable || 'N/A'}</td><td class="px-6 py-4 text-slate-600 text-sm justification-cell" title="${item.justification}">${item.justification}</td><td class="px-6 py-4 text-sm">${linkHtml}</td>`;
        return row;
    }

    const sortableTableInstance = initSortableTable(tableEl, [], renderTableRow, { defaultSortKey: 'type', defaultSortDir: 'asc' });

    const updateView = () => {
        const searchTerm = searchInput ? searchInput.value.toLowerCase() : '';
        const typeValue = typeFilter ? typeFilter.value : 'all';
        const ringValue = ringFilter ? ringFilter.value : 'all';
        const squadValue = squadFilter ? squadFilter.value : 'all';
        const quadrantValue = quadrantFilter ? quadrantFilter.value : 'all';
        const projectValue = projectFilter ? projectFilter.value : 'all';

        let techIdsForUsageFilter;

        if (squadValue !== 'all' || projectValue !== 'all') {
            const allUsageData = [...technologiesData, ...pratiquesData];
            const filteredUsage = allUsageData.filter(u =>
                (squadValue === 'all' || u.squad === squadValue) &&
                (projectValue === 'all' || u.project_code === projectValue)
            );
            techIdsForUsageFilter = new Set(filteredUsage.map(u => u.radar_id));
        }

        const filteredData = processedRadarData.filter(item => {
            const searchMatch = item.name.toLowerCase().includes(searchTerm) || item.justification.toLowerCase().includes(searchTerm);
            const typeMatch = typeValue === 'all' || item.type === typeValue;
            const ringMatch = ringValue === 'all' || item.ring === ringValue;
            const quadrantMatch = quadrantValue === 'all' || item.quadrant === quadrantValue;
            const usageMatch = !techIdsForUsageFilter || techIdsForUsageFilter.has(item.id);
            return searchMatch && typeMatch && ringMatch && quadrantMatch && usageMatch;
        });
        currentlyDisplayedData = filteredData;
        
        const padding = 20;
        const radarSize = wrapper.offsetWidth - padding;
        
        container.style.width = `${radarSize}px`;
        container.style.height = `${radarSize}px`;
        
        renderRadar(filteredData, container, radarSize, ringsData);
        sortableTableInstance.update(filteredData);
    };
    
    const debouncedUpdateView = debounce(updateView, 150);

    [searchInput, typeFilter, ringFilter, squadFilter, quadrantFilter, projectFilter].forEach(el => {
        if (el) {
            if (!el.dataset.listenerAttached) {
                const eventType = el.tagName === 'INPUT' ? 'input' : 'change';
                el.addEventListener(eventType, debouncedUpdateView);
                el.dataset.listenerAttached = 'true';
            }
        } else {
            console.warn(`A filter element was not found in the DOM and will be ignored.`);
        }
    });
    
    window.addEventListener('resize', debouncedUpdateView);
    
    renderRingLegend(ringsData);
    renderQuadrantLegend(quadrantsData);
    setupHighlighting();
    makeTableResizable(tableEl);

    if (!modal.dataset.eventsAttached) {
        modalClose.addEventListener('click', hideModal);
        modal.addEventListener('click', (e) => { if (e.target.id === 'radar-modal') hideModal(); });
        modal.dataset.eventsAttached = 'true';
    }


    if (exportBtn && !exportBtn.dataset.listenerAttached) {
        exportBtn.addEventListener('click', () => {
            const headers = { type: 'Type', name: 'Nom', quadrant: 'Quadrant', ring: 'Anneau', responsable: 'Responsable(s)', justification: 'Justification', link: 'Lien' };
            exportToCsv('tech_radar_export.csv', currentlyDisplayedData, headers);
        });
        exportBtn.dataset.listenerAttached = 'true';
    }

    updateView();
}
