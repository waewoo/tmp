/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Helper to sort mixed-type data consistently.
 * Uses localeCompare with numeric option for "natural" sorting.
 * @param {any} a - First value.
 * @param {any} b - Second value.
 * @returns {number} - Sort order.
 */
function compareValues(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
}

/**
 * Initializes a table to be sortable.
 * @param {HTMLTableElement} tableEl - The table element.
 * @param {Array<Object>} initialData - The initial array of data objects.
 * @param {function(Object): HTMLTableRowElement} renderRow - A function that takes a data object and returns a <tr> element.
 * @param {object} [options] - Optional configuration.
 * @param {string} [options.defaultSortKey] - The key to sort by default.
 * @param {string} [options.defaultSortDir] - The default sort direction ('asc' or 'desc').
 * @returns {{update: function(Array<Object>), getCurrentData: function(): Array<Object>}} - An object with methods to update and retrieve table data.
 */
export function initSortableTable(tableEl, initialData, renderRow, options = {}) {
    const thead = tableEl.querySelector('thead');
    let tbody = tableEl.querySelector('tbody');
    if (!tbody) {
        tbody = document.createElement('tbody');
        tbody.className = "bg-white divide-y divide-slate-200";
        tableEl.appendChild(tbody);
    }
    
    const headers = thead.querySelectorAll('th[data-sort-key]');

    let currentData = [...initialData];
    let sortedData = [...initialData];
    let sortState = { 
        key: options.defaultSortKey || null, 
        direction: options.defaultSortDir || 'asc' 
    };

    function render() {
        // Create a copy to sort, preserving the original filtered order
        sortedData = [...currentData];

        // Sort data if a sort key is set
        if (sortState.key) {
            sortedData.sort((a, b) => {
                const valA = a[sortState.key];
                const valB = b[sortState.key];
                const order = compareValues(valA, valB);
                return sortState.direction === 'asc' ? order : -order;
            });
        }

        // Clear and render rows more efficiently
        tbody.innerHTML = '';

        if (sortedData.length === 0) {
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.colSpan = headers.length;
            td.className = 'text-center py-8 text-slate-500';
            td.textContent = 'Aucun résultat trouvé.';
            tr.appendChild(td);
            tbody.appendChild(tr);
        } else {
            const fragment = document.createDocumentFragment();
            sortedData.forEach(item => {
                fragment.appendChild(renderRow(item));
            });
            tbody.appendChild(fragment);
        }

        // Update headers for accessibility and visual feedback
        headers.forEach(header => {
            const key = header.dataset.sortKey;
            const icon = header.querySelector('.sort-icon');
            if (!icon) return;

            if (key === sortState.key) {
                header.setAttribute('aria-sort', sortState.direction === 'asc' ? 'ascending' : 'descending');
                icon.textContent = sortState.direction === 'asc' ? '↑' : '↓';
            } else {
                header.removeAttribute('aria-sort');
                icon.textContent = '↕';
            }
        });
    }

    headers.forEach(header => {
        header.addEventListener('click', () => {
            const key = header.dataset.sortKey;
            if (sortState.key === key) {
                // If same column, toggle direction
                sortState.direction = sortState.direction === 'asc' ? 'desc' : 'asc';
            } else {
                // If new column, set key and default to ascending
                sortState.key = key;
                sortState.direction = 'asc';
            }
            render();
        });
    });

    /**
     * Updates the table with a new set of data.
     * @param {Array<Object>} newData - The new data to display.
     */
    function update(newData) {
        currentData = [...newData];
        // Re-render with the new data, preserving the current sort state
        render();
    }

    /**
     * Returns the currently displayed (and sorted) data.
     * @returns {Array<Object>}
     */
    function getCurrentData() {
        return sortedData;
    }

    // Initial render on load
    render();

    return { update, getCurrentData };
}
