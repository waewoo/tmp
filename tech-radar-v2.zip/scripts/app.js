/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Point d'entrée principal de l'application.
 * Gère le chargement des données, la navigation entre les vues,
 * l'initialisation des modules et l'affichage des erreurs.
 */

import { loadData } from './data.js';
import { initApercu } from './apercu.js';
import { initRadar } from './radar.js';
import { initDashboard, setActiveTab as setDashboardTab } from './dashboard.js';

const APP_CONFIG = {
    paths: {
        conf: 'conf/',
        data: 'data/'
    }
};

const initializedViews = new Set();
let appData = null;
const spinner = document.getElementById('loading-spinner');

/**
 * Affiche les erreurs de validation des données dans les conteneurs d'erreurs dédiés.
 * @param {Array<{message: string}>} errors - Une liste d'objets d'erreur, chacun avec une propriété `message`.
 */
function displayErrors(errors) {
    const errorHtml = errors.map(e => {
        const div = document.createElement('div');
        div.className = 'bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-2 rounded';
        div.setAttribute('role', 'alert');
        div.innerHTML = `<p class="font-bold">Erreur de Cohérence des Données</p><p>${e.message}</p>`;
        return div;
    });
    
    const containers = [
        document.getElementById('apercu-error-container'),
        document.getElementById('dashboard-error-container'),
        document.getElementById('radar-error-container'),
    ];
    
    containers.forEach(container => {
        if(container) {
            container.innerHTML = '';
            errorHtml.forEach(el => container.appendChild(el.cloneNode(true)));
        }
    });
}

/**
 * Affiche une vue spécifique de l'application et masque les autres.
 * Initialise la vue si elle n'a pas encore été chargée.
 * @param {string} viewId - L'ID de la vue à afficher ('apercu', 'radar', 'dashboard').
 * @param {object} [filterOptions={}] - Options de filtrage à passer à la vue (ex: pour le tableau de bord).
 */
function showView(viewId, filterOptions = {}) {
    if (!appData) return;

    const views = document.querySelectorAll('.view');
    const navLinks = document.querySelectorAll('.nav-link');

    views.forEach(view => view.classList.add('hidden'));
    document.getElementById(`${viewId}-view`).classList.remove('hidden');
    
    navLinks.forEach(link => {
        const isActive = link.dataset.view === viewId;
        link.classList.toggle('active', isActive);
        if (isActive) {
            link.setAttribute('aria-current', 'page');
        } else {
            link.removeAttribute('aria-current');
        }
    });

    if (!initializedViews.has(viewId)) {
        switch (viewId) {
            case 'apercu':
                initApercu(appData);
                break;
            case 'radar':
                initRadar(appData);
                break;
            case 'dashboard':
                initDashboard(appData);
                break;
        }
        initializedViews.add(viewId);
    }
    
    if (viewId === 'radar') {
        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 100); 
    }
    
    if (viewId === 'dashboard') {
        if(filterOptions.subView) {
            setDashboardTab(filterOptions.subView);
        }
        if (filterOptions.status) {
            const squadFilter = document.getElementById('filter-squad');
            if (squadFilter) squadFilter.value = 'all';

            const statusFilter = document.getElementById('filter-status');
            if (statusFilter) {
                statusFilter.value = filterOptions.status;
                statusFilter.dispatchEvent(new Event('change'));
            }
        }
    }
}

// Expose showView globalement pour qu'elle puisse être appelée depuis d'autres modules ou scripts.
window.showView = showView;

/**
 * Gère l'événement de chargement de la fenêtre.
 * Charge les données de l'application, initialise la navigation et affiche la vue par défaut.
 */
window.addEventListener('load', async () => {
    try {
        // Charge toutes les données nécessaires au fonctionnement de l'application.
        appData = await loadData(APP_CONFIG.paths);
        
        // Si des erreurs de cohérence ont été détectées, les afficher.
        if (appData.errors && appData.errors.length > 0) {
            displayErrors(appData.errors);
        }

        // Ajoute les écouteurs d'événements pour la navigation principale.
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const view = e.currentTarget.dataset.view;
                if (view) {
                    showView(view);
                }
            });
        });
        
        // Affiche la vue par défaut au chargement.
        showView('apercu');

    } catch (error) {
        // En cas d'erreur critique (ex: impossible de charger un fichier), afficher un message d'erreur bloquant.
        console.error("Failed to load application data:", error);
        const errorDiv = document.createElement('div');
        errorDiv.className = "bg-red-100 border-l-4 border-red-500 text-red-700 p-4 m-4";
        errorDiv.setAttribute('role', 'alert');
        errorDiv.innerHTML = `<p class="font-bold">Erreur Critique</p><p>Impossible de charger les données de l'application.</p><pre class="mt-2 text-sm"></pre>`;
        errorDiv.querySelector('pre').textContent = error.message;
        document.body.innerHTML = '';
        document.body.appendChild(errorDiv);
    } finally {
        // Masque le spinner de chargement une fois que tout est terminé.
        spinner.classList.add('hidden');
    }
});
