/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Gère la logique et le rendu pour la vue "Tableau de Bord".
 * Inclut les matrices d'adoption, le catalogue des usages et la navigation par onglets.
 */

import { initSortableTable } from './sortable-table.js';

let globalData = null;

const ringColors = {
    'Adopt': 'bg-green-100 text-green-800', 'Trial': 'bg-blue-100 text-blue-800',
    'Assess': 'bg-yellow-100 text-yellow-800', 'Hold': 'bg-red-100 text-red-800'
};

/**
 * Exporte des données au format CSV et déclenche le téléchargement.
 * @param {string} filename - Le nom du fichier à télécharger.
 * @param {Array<Object>} dataToExport - Le tableau d'objets à exporter.
 * @param {Object.<string, string>} [headers] - Un objet mappant les clés de données aux en-têtes de colonnes CSV.
 */
function exportToCsv(filename, dataToExport, headers) {
    if (!dataToExport || dataToExport.length === 0) {
        alert("Aucune donnée à exporter.");
        return;
    }

    const columnKeys = headers ? Object.keys(headers) : Object.keys(dataToExport[0]);
    const headerValues = headers ? Object.values(headers) : columnKeys;
    
    // Ajoute le BOM (Byte Order Mark) pour assurer la compatibilité avec Excel pour les caractères UTF-8.
    const csvRows = ['\uFEFF' + headerValues.join(',')];

    for (const row of dataToExport) {
        const values = columnKeys.map(key => {
            if (typeof row[key] === 'object' && row[key] !== null) {
                return `"${JSON.stringify(row[key]).replace(/"/g, '""')}"`;
            }
            let cell = row[key] === null || row[key] === undefined ? '' : String(row[key]);
            // Échappe les guillemets doubles en les doublant.
            cell = cell.replace(/"/g, '""');
            // Met la cellule entre guillemets si elle contient une virgule, un guillemet ou un saut de ligne.
            if (cell.search(/("|,|\n)/g) >= 0) {
                cell = `"${cell}"`;
            }
            return cell;
        });
        csvRows.push(values.join(','));
    }

    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });

    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}


/**
 * Retourne la classe de couleur Tailwind CSS pour un code d'anneau donné.
 * @param {string} ringCode - Le code de l'anneau (ex: 'Adopt', 'Trial').
 * @returns {string} La classe de couleur correspondante.
 */
function getRingColorClass(ringCode) {
    return ringColors[ringCode] || 'bg-slate-100 text-slate-800';
}

/**
 * Crée un élément DOM pour la légende des statuts.
 * @param {object} item - L'objet de statut contenant nom, icône, description.
 * @returns {HTMLElement} L'élément de légende créé.
 */
function createLegendItem(item) {
    const wrapper = document.createElement('div');
    wrapper.className = 'flex items-start bg-white p-4 rounded-lg shadow-sm';

    const icon = document.createElement('div');
    icon.className = 'text-2xl mr-4';
    icon.textContent = item.icon;
    icon.setAttribute('aria-hidden', 'true');

    const textWrapper = document.createElement('div');
    const title = document.createElement('p');
    title.className = 'font-semibold text-slate-800';
    title.textContent = item.name;
    const description = document.createElement('p');
    description.className = 'text-sm text-slate-600';
    description.textContent = item.description;

    textWrapper.append(title, description);
    wrapper.append(icon, textWrapper);
    return wrapper;
}

/**
 * Génère et affiche la légende des statuts dans le DOM.
 * @param {Array<Object>} statusesData - Le tableau des données de statuts.
 */
function renderStatusLegend(statusesData) {
    const legendContainer = document.getElementById('status-legend');
    if (!legendContainer) return;
    legendContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();
    const decomCode = 'decom';
    statusesData.filter(s => s.code !== decomCode).forEach(item => {
        fragment.appendChild(createLegendItem(item));
    });
    legendContainer.appendChild(fragment);
}

/**
 * Génère et affiche la légende pour les matrices (Adopté, Partiel, Non Adopté).
 */
function renderMatrixLegend() {
    const container = document.getElementById('matrix-legend-container');
    if (!container) return;

    const legendData = [
        { name: 'Adopté / Conforme', description: 'La pratique est pleinement adoptée ou la règle est respectée.', color: 'var(--color-success)' },
        { name: 'Partiel / En cours', description: "L'adoption est partielle, en cours de déploiement, ou la règle n'est que partiellement respectée.", color: 'var(--color-warning)' },
        { name: 'Non Adopté / Non Conforme', description: "La pratique n'est pas en place ou la règle n'est pas du tout respectée.", color: 'var(--color-danger)' }
    ];

    container.innerHTML = ''; // Clear previous content

    const title = document.createElement('h3');
    title.className = 'text-xl font-semibold text-slate-800 mb-4';
    title.textContent = 'Légende des Matrices';

    const grid = document.createElement('div');
    grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4';

    legendData.forEach(item => {
        const card = document.createElement('div');
        card.className = 'flex items-start bg-white p-4 rounded-lg shadow-sm';

        const colorIndicator = document.createElement('span');
        colorIndicator.className = 'w-5 h-5 rounded-md mr-4 mt-1 flex-shrink-0';
        colorIndicator.style.backgroundColor = item.color;
        colorIndicator.setAttribute('aria-hidden', 'true');

        const textDiv = document.createElement('div');
        const nameP = document.createElement('p');
        nameP.className = 'font-semibold text-slate-800';
        nameP.textContent = item.name;
        const descP = document.createElement('p');
        descP.className = 'text-sm text-slate-600';
        descP.textContent = item.description;

        textDiv.append(nameP, descP);
        card.append(colorIndicator, textDiv);
        grid.appendChild(card);
    });

    container.append(title, grid);
}

/**
 * Transforme les données plates en une structure de matrice et calcule le taux d'adoption.
 * @param {Array<Object>} flatData - Données sources (pratiques ou orchestrateur).
 * @param {string[]} allSquads - La liste de toutes les squads pour le calcul du taux.
 * @param {boolean} isOrchestrateur - Indique si les données concernent l'orchestrateur.
 * @returns {Array<Object>} Les données traitées pour la matrice.
 */
function processMatrixData(flatData, allSquads, isOrchestrateur) {
    // Cette opération "reduce" est un pivot : elle transforme une liste de lignes (flatData)
    // en un objet groupé par pratique/règle, ce qui est la structure nécessaire pour une matrice.
    const matrixData = flatData.reduce((acc, item) => {
        const key = isOrchestrateur ? item.id : item.radar_id;
        if (!acc[key]) {
            acc[key] = {
                id: key,
                name: item.name,
                type: item.type,
                ring: item.ring,
                ring_code: item.ring_code,
                statuses: {}
            };
        }
        acc[key].statuses[item.squad] = item.status;
        return acc;
    }, {});
    
    return Object.values(matrixData).map(item => {
        let ouiCount = 0;
        let partielCount = 0;
        Object.values(item.statuses).forEach(status => {
            if (status === 'Oui') ouiCount++;
            else if (status === 'Partiel') partielCount++;
        });
        // Règle métier clé : une adoption "Partielle" compte pour 50% d'une adoption "Oui".
        const adoptionRate = Math.round(((ouiCount + partielCount * 0.5) / allSquads.length) * 100);
        return { ...item, adoptionRate };
    });
}

/**
 * Initialise une matrice (pratiques ou orchestrateur) avec ses filtres et sa logique de rendu.
 * @param {object} config - L'objet de configuration pour la matrice.
 * @param {string} config.containerId - L'ID du conteneur du filtre (ex: 'pratiques').
 * @param {string} config.tableId - L'ID de la table HTML.
 * @param {Array<Object>} config.flatData - Les données brutes à afficher.
 * @param {string[]} config.allSquads - La liste de toutes les squads.
 * @param {boolean} [config.isOrchestrateur=false] - Indique s'il s'agit de la matrice de l'orchestrateur.
 * @param {Array<Object>} config.typesData - Les données des types.
 * @param {Array<Object>} config.projectsData - Les données des projets.
 * @param {Array<Object>} [config.orchestrateurTypesData] - Les données des types de l'orchestrateur.
 */
function initMatrixWithFilters(config) {
    const {
        containerId,
        tableId,
        flatData,
        allSquads,
        isOrchestrateur = false,
        typesData,
        projectsData,
        orchestrateurTypesData
    } = config;

    const table = document.getElementById(tableId);
    if (!table) return;

    const rateFilter = document.getElementById(`${containerId}-rate-filter`);
    const typeFilter = document.getElementById(`${containerId}-type-filter`);
    const projectFilter = document.getElementById(`${containerId}-project-filter`);
    const exportBtn = document.getElementById(`export-${containerId}-btn`);
    let displayData = [];

    if (typeFilter && typeFilter.options.length <= 1) {
        let availableTypes;
        if (isOrchestrateur) {
            // Pour la matrice orchestrateur, on utilise les types prédéfinis.
            availableTypes = orchestrateurTypesData.map(t => t.name).sort();
        } else {
            // Pour la matrice des pratiques, on dérive les types des données réelles
            // pour n'afficher que les types qui ont au moins une pratique associée, rendant le filtre plus pertinent.
            const uniqueTypes = [...new Set(flatData.map(item => item.type))];
            availableTypes = uniqueTypes.filter(t => t).sort(); // Filtre les types vides et trie.
        }
        
        availableTypes.forEach(type => {
            typeFilter.add(new Option(type, type));
        });
    }

    if (projectFilter && projectFilter.options.length <= 1) {
        projectsData.forEach(p => projectFilter.add(new Option(p.name, p.code)));
    }
    
    let sortState = { key: 'type', direction: 'asc' };

    function compareValues(a, b) {
        return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });
    }

    function renderTableHeader() {
        let thead = table.querySelector('thead');
        if (!thead) {
            thead = document.createElement('thead');
            table.prepend(thead);
        }
        thead.innerHTML = '';
        thead.className = 'bg-slate-50';
        const headerRow = document.createElement('tr');
        
        const sortableHeaderClass = "px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider";
        const nonSortableHeaderClass = "vertical-header text-xs font-medium text-slate-500 uppercase tracking-wider";

        let headerHtml = isOrchestrateur
            ? `<th scope="col" class="${sortableHeaderClass}" data-sort-key="type">Type<span class="sort-icon"></span></th>
               <th scope="col" class="${sortableHeaderClass}" data-sort-key="name">Règle<span class="sort-icon"></span></th>`
            : `<th scope="col" class="${sortableHeaderClass}" data-sort-key="type">Type<span class="sort-icon"></span></th>
               <th scope="col" class="${sortableHeaderClass}" data-sort-key="name">Pratique<span class="sort-icon"></span></th>
               <th scope="col" class="${sortableHeaderClass}" data-sort-key="ring">Anneau<span class="sort-icon"></span></th>`;
        
        allSquads.forEach(squad => {
            headerHtml += `<th scope="col" class="${nonSortableHeaderClass}">${squad}</th>`;
        });
        
        headerHtml += `<th scope="col" class="${sortableHeaderClass}" data-sort-key="adoptionRate">Taux Adoption<span class="sort-icon"></span></th>`;
        headerRow.innerHTML = headerHtml;
        thead.appendChild(headerRow);
    }
    
    function render() {
        const rateValue = rateFilter ? rateFilter.value : 'all';
        const typeValue = typeFilter ? typeFilter.value : 'all';
        const projectValue = projectFilter ? projectFilter.value : 'all';

        const filteredFlatData = flatData.filter(item => projectValue === 'all' || item.project_code === projectValue);
        const processedData = processMatrixData(filteredFlatData, allSquads, isOrchestrateur);

        let filtered = processedData.filter(item => {
            const typeMatch = typeValue === 'all' || item.type === typeValue;
            if (!typeMatch) return false;

            const rate = item.adoptionRate;
            if (rateValue === 'all') return true;
            if (rateValue === 'good') return rate >= 75;
            if (rateValue === 'medium') return rate >= 40 && rate < 75;
            if (rateValue === 'low') return rate < 40;
            return true;
        });
        
        if (sortState.key) {
            filtered.sort((a, b) => {
                let valA = a[sortState.key];
                let valB = b[sortState.key];
                valA = valA === undefined || valA === null ? '' : valA;
                valB = valB === undefined || valB === null ? '' : valB;
                const order = compareValues(valA, valB);
                return sortState.direction === 'asc' ? order : -order;
            });
        }

        displayData = filtered;
        
        let tbody = table.querySelector('tbody');
        if (!tbody) {
            tbody = document.createElement('tbody');
            table.appendChild(tbody);
        }
        tbody.innerHTML = '';
        tbody.className = 'bg-white divide-y divide-slate-200';

        if (displayData.length === 0) {
            const tr = document.createElement('tr');
            const td = document.createElement('td');
            td.colSpan = (isOrchestrateur ? 2 : 3) + allSquads.length + 1;
            td.className = 'text-center py-8 text-slate-500';
            td.textContent = 'Aucun résultat trouvé.';
            tr.appendChild(td);
            tbody.appendChild(tr);
        } else {
            displayData.forEach(item => {
                const row = document.createElement('tr');
                let cellsHtml = isOrchestrateur
                    ? `<td class="text-sm text-slate-500 px-6 py-4">${item.type}</td>
                       <td class="font-medium text-sm text-slate-900 px-6 py-4">${item.name}</td>`
                    : `<td class="text-sm text-slate-500 px-6 py-4">${item.type}</td>
                       <td class="font-medium text-sm text-slate-900 px-6 py-4">${item.name}</td>
                       <td class="px-6 py-4 whitespace-nowrap"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRingColorClass(item.ring_code)}">${item.ring}</span></td>`;
                
                allSquads.forEach(squad => {
                    const status = item.statuses[squad] || 'Non';
                    let colorClass = 'var(--color-danger)';
                    if (status === 'Oui') colorClass = 'var(--color-success)';
                    else if (status === 'Partiel') colorClass = 'var(--color-warning)';
                    cellsHtml += `<td class="px-6 py-4"><div class="w-4 h-4 rounded-full mx-auto" title="${status}" style="background-color: ${colorClass};"></div></td>`;
                });
    
                const rate = item.adoptionRate;
                let rateColorClass = 'text-red-600';
                if (rate >= 75) rateColorClass = 'text-green-600';
                else if (rate >= 40) rateColorClass = 'text-yellow-600';
                
                cellsHtml += `<td class="font-semibold text-sm px-6 py-4 ${rateColorClass}">${rate}%</td>`;
                
                row.innerHTML = cellsHtml;
                tbody.appendChild(row);
            });
        }
        
        const thead = table.querySelector('thead');
        thead.querySelectorAll('th[data-sort-key]').forEach(header => {
            const key = header.dataset.sortKey;
            const icon = header.querySelector('.sort-icon');
            if (icon) {
                if (key === sortState.key) {
                    header.setAttribute('aria-sort', sortState.direction === 'asc' ? 'ascending' : 'descending');
                    icon.textContent = sortState.direction === 'asc' ? '↑' : '↓';
                } else {
                    header.removeAttribute('aria-sort');
                    icon.textContent = '↕';
                }
            }
        });
    }

    renderTableHeader();
    table.querySelector('thead').addEventListener('click', e => {
        const header = e.target.closest('th[data-sort-key]');
        if (header) {
            const key = header.dataset.sortKey;
            if (sortState.key === key) {
                sortState.direction = sortState.direction === 'asc' ? 'desc' : 'asc';
            } else {
                sortState.key = key;
                sortState.direction = 'asc';
            }
            render();
        }
    });
    
    [rateFilter, typeFilter, projectFilter].forEach(filter => {
        if(filter) filter.addEventListener('change', render);
    });

    if (exportBtn && !exportBtn.dataset.listenerAttached) {
        exportBtn.addEventListener('click', () => {
            const dataToExport = displayData.map(item => {
                const row = {
                    type: item.type,
                    name: item.name,
                };
                if (!isOrchestrateur) {
                    row.ring = item.ring;
                }
                allSquads.forEach(squad => {
                    row[squad] = item.statuses[squad] || 'Non';
                });
                row.adoptionRate = `${item.adoptionRate}%`;
                return row;
            });

            const headers = {
                type: 'Type',
                name: isOrchestrateur ? 'Règle' : 'Pratique',
            };
            if (!isOrchestrateur) {
                headers.ring = 'Anneau';
            }
            allSquads.forEach(squad => {
                headers[squad] = squad;
            });
            headers.adoptionRate = 'Taux Adoption';
            
            const filename = isOrchestrateur ? 'export_matrice_orchestrateur.csv' : 'export_matrice_pratiques.csv';
            exportToCsv(filename, dataToExport, headers);
        });
        exportBtn.dataset.listenerAttached = 'true';
    }


    render();
}

/**
 * Initialise le tableau du catalogue des usages technologiques avec des filtres et le tri.
 * @param {Array<Object>} technologiesData - Les données enrichies des technologies.
 * @param {Array<Object>} statusesData - Les données des statuts pour le filtre.
 * @param {Array<Object>} projectsData - Les données des projets pour le filtre.
 */
function initCatalogueTable(technologiesData, statusesData, projectsData) {
    const squadFilter = document.getElementById('filter-squad');
    const statusFilter = document.getElementById('filter-status');
    const projectFilter = document.getElementById('filter-project');
    const table = document.getElementById('catalogue-table');
    const exportBtn = document.getElementById('export-catalogue-btn');

    if (!table) return;

    if (squadFilter && squadFilter.options.length <= 1) {
        const squads = [...new Set(technologiesData.map(item => item.squad))].sort();
        squads.forEach(squad => squadFilter.add(new Option(squad, squad)));
    }
    if (statusFilter && statusFilter.options.length <= 1) {
        statusesData.filter(s => s.code !== 'decom').forEach(s => statusFilter.add(new Option(`${s.icon} ${s.name}`, s.name)));
    }
    if (projectFilter && projectFilter.options.length <= 1) {
        projectsData.forEach(p => projectFilter.add(new Option(p.name, p.code)));
    }


    function renderRow(item) {
        const color = item.status_color || '#9ca3af';
        const row = document.createElement('tr');
        
        const adrLink = document.createElement('a');
        adrLink.href = item.adrLink;
        adrLink.target = '_blank';
        adrLink.className = 'text-sky-600 hover:text-sky-800 underline';
        adrLink.textContent = "Voir l'ADR";
        
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm font-mono text-slate-500">${item.id || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap"><div class="text-sm font-medium text-slate-900">${item.name || 'N/A'}</div></td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${item.quadrant || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${item.type || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${item.squad}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500">${item.projectName || 'N/A'}</td>
            <td class="px-6 py-4 whitespace-nowrap"><span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full text-slate-800" style="background-color: ${color}20;">${item.status_icon || '❓'} ${item.status}</span></td>
            <td class="px-6 py-4 text-sm text-slate-700">${item.comment}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-700">${item.action}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm"></td>
        `;

        if (item.adrLink) {
            row.cells[9].appendChild(adrLink);
        } else {
            row.cells[9].textContent = 'N/A';
        }

        return row;
    }
    
    const sortableTable = initSortableTable(table, technologiesData, renderRow);

    function applyFilters() {
        const squad = squadFilter ? squadFilter.value : 'all';
        const status = statusFilter ? statusFilter.value : 'all';
        const project = projectFilter ? projectFilter.value : 'all';

        const filteredData = technologiesData.filter(item => 
            (squad === 'all' || item.squad === squad) &&
            (status === 'all' || item.status === status) &&
            (project === 'all' || item.project_code === project)
        );
        
        sortableTable.update(filteredData);
    }

    [squadFilter, statusFilter, projectFilter].forEach(filter => {
        if (filter && !filter.dataset.listenerAttached) {
            filter.addEventListener('change', applyFilters);
            filter.dataset.listenerAttached = 'true';
        }
    });

    if (exportBtn && !exportBtn.dataset.listenerAttached) {
        exportBtn.addEventListener('click', () => {
            const dataForExport = sortableTable.getCurrentData();
            const headers = {
                id: 'ID',
                name: 'Technologie',
                quadrant: 'Quadrant',
                type: 'Type',
                squad: 'Squad',
                projectName: 'Projet',
                status: 'Statut',
                comment: 'Commentaire',
                action: 'Action Requise',
                adrLink: 'Lien ADR'
            };
            exportToCsv('export_catalogue_usages.csv', dataForExport, headers);
        });
        exportBtn.dataset.listenerAttached = 'true';
    }


    applyFilters();
}

/**
 * Affiche une sous-vue spécifique du tableau de bord (Matrices ou Catalogue).
 * @param {string} subViewId - L'ID de la sous-vue à afficher ('matrices' ou 'catalogue').
 */
function showSubView(subViewId) {
    const subViews = document.querySelectorAll('#dashboard-view .sub-view');
    const subNavLinks = document.querySelectorAll('#dashboard-sub-nav .sub-nav-link');

    subViews.forEach(view => view.classList.add('hidden'));
    const activeView = document.getElementById(`dashboard-${subViewId}`);
    if(activeView) activeView.classList.remove('hidden');

    subNavLinks.forEach(link => {
        const isActive = link.dataset.subView === subViewId;
        link.classList.toggle('active', isActive);
        if (isActive) {
            link.setAttribute('aria-current', 'page');
        } else {
            link.removeAttribute('aria-current');
        }
    });
}

/**
 * Active un onglet spécifique du tableau de bord.
 * @param {string} subViewId - L'ID de la sous-vue à activer.
 */
export function setActiveTab(subViewId) {
    showSubView(subViewId);
}

/**
 * Point d'entrée pour initialiser la vue "Tableau de Bord".
 * @param {object} data - L'objet de données global de l'application.
 */
export function initDashboard(data) {
    globalData = data;
    const { statusesData, allSquads, pratiquesData, orchestrateurData, technologiesData, typesData, projectsData, orchestrateurTypesData } = data;
    
    const subNav = document.getElementById('dashboard-sub-nav');
    if (!subNav.dataset.listenerAttached) {
        subNav.addEventListener('click', (e) => {
            e.preventDefault();
            const subView = e.target.closest('a')?.dataset.subView;
            if (subView) {
                showSubView(subView);
            }
        });
        subNav.dataset.listenerAttached = 'true';
    }

    renderMatrixLegend();
    renderStatusLegend(statusesData);
    
    initMatrixWithFilters({
        containerId: 'pratiques',
        tableId: 'pratiques-matrix-table',
        flatData: pratiquesData,
        allSquads: allSquads,
        typesData: typesData,
        projectsData: projectsData,
    });
    
    initMatrixWithFilters({
        containerId: 'orchestrateur',
        tableId: 'orchestrateur-matrix-table',
        flatData: orchestrateurData,
        allSquads: allSquads,
        isOrchestrateur: true,
        projectsData: projectsData,
        orchestrateurTypesData: orchestrateurTypesData
    });

    initCatalogueTable(technologiesData, statusesData, projectsData);
    
    if (!document.querySelector('#dashboard-sub-nav .active')) {
        showSubView('matrices');
    }
}