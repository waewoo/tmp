/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Gère le chargement, le parsing, la validation et l'enrichissement des données de l'application.
 * Peut charger des données à partir de fichiers CSV locaux ou (à l'avenir) d'une base de données distante.
 */


/**
 * Un parseur CSV robuste qui gère les champs entre guillemets contenant des virgules et des sauts de ligne.
 * @param {string} text - Le texte CSV brut.
 * @returns {Array<Object>} Un tableau d'objets, où chaque objet représente une ligne du CSV.
 */
function parseCsv(text) {
    const lines = text.trim().split('\n');
    if (lines.length === 0 || (lines.length === 1 && lines[0] === '')) return [];
    const header = lines[0].split(',').map(h => h.trim());
    const rows = [];
    let currentRow = [];
    // `inQuotedField` agit comme un automate à états pour savoir si nous sommes à l'intérieur d'un champ protégé par des guillemets.
    let inQuotedField = false;

    for (let i = 1; i < lines.length; i++) {
        let line = lines[i];
        // Si nous sommes déjà dans un champ multi-lignes, on ajoute simplement la nouvelle ligne au champ précédent.
        if (inQuotedField) {
            currentRow[currentRow.length - 1] += '\n' + line;
        } else {
            if (currentRow.length > 0) {
                rows.push(currentRow);
            }
            currentRow = [];
            let field = '';
            // On parcourt la ligne caractère par caractère pour gérer les délimiteurs.
            for (const char of line) {
                if (char === '"') {
                    inQuotedField = !inQuotedField; // Inverse l'état
                } else if (char === ',' && !inQuotedField) {
                    currentRow.push(field.trim());
                    field = '';
                } else {
                    field += char;
                }
            }
            currentRow.push(field.trim());
        }
        
        // Après avoir traité une ligne, on vérifie si un champ entre guillemets a été correctement fermé
        // en s'assurant que le nombre de guillemets est pair.
        if (currentRow.length > 0) {
            const lastField = currentRow[currentRow.length - 1];
            if ((lastField.split('"').length - 1) % 2 === 0) {
                inQuotedField = false;
            }
        }
    }
    if (currentRow.length > 0) {
        rows.push(currentRow);
    }
    
    return rows.map(rowValues => {
        const obj = {};
        for (let j = 0; j < header.length; j++) {
            let value = rowValues[j] || '';
            // Supprime les guillemets de début et de fin du champ.
            if (value.startsWith('"') && value.endsWith('"')) {
                value = value.substring(1, value.length - 1);
            }
            // Remplace les guillemets doubles (échappés) par un seul guillemet.
            obj[header[j]] = value.replace(/""/g, '"');
        }
        return obj;
    });
}

/**
 * Charge les données à partir de fichiers CSV locaux.
 * @param {object} paths - Un objet contenant les chemins vers les répertoires de données (`conf` et `data`).
 * @returns {Promise<Object>} Une promesse qui se résout en un objet contenant toutes les données de l'application,
 * y compris les données enrichies, les listes de référence et un tableau d'erreurs de validation.
 */
async function loadDataFromCsv(paths) {
     const [
        ringsText,
        quadrantsText,
        typesText,
        responsablesText,
        statusesText,
        projectsText,
        radarDataText, 
        technologiesDataText, 
        pratiquesDataText,
        orchestrateurDataText,
        orchestrateurTypesText,
    ] = await Promise.all([
        fetch(`${paths.conf}rings_data.csv`).then(res => res.text()),
        fetch(`${paths.conf}quadrants_data.csv`).then(res => res.text()),
        fetch(`${paths.conf}types_data.csv`).then(res => res.text()),
        fetch(`${paths.data}responsables_data.csv`).then(res => res.text()), // Moved to data/
        fetch(`${paths.conf}statuses_data.csv`).then(res => res.text()),
        fetch(`${paths.data}projects_data.csv`).then(res => res.text()),
        fetch(`${paths.data}radar_data.csv`).then(res => res.text()),
        fetch(`${paths.data}technologies_data.csv`).then(res => res.text()),
        fetch(`${paths.data}pratiques_data.csv`).then(res => res.text()),
        fetch(`${paths.data}orchestrateur_data.csv`).then(res => res.text()),
        fetch(`${paths.data}orchestrateur_types_data.csv`).then(res => res.text()), // Moved to data/
    ]);

    // Create maps from mapping files
    const ringsMap = new Map(parseCsv(ringsText).map(item => [item.code, item]));
    const quadrantsMap = new Map(parseCsv(quadrantsText).map(item => [item.code, item]));
    const typesMap = new Map(parseCsv(typesText).map(item => [item.code, item]));
    const responsablesMap = new Map(parseCsv(responsablesText).map(item => [item.code, item]));
    const statusesMap = new Map(parseCsv(statusesText).map(item => [item.code, item]));
    const orchestrateurTypesMap = new Map(parseCsv(orchestrateurTypesText).map(item => [item.code, item]));
    const projectsMap = new Map(parseCsv(projectsText).map(item => [item.code, item]));

    // Parse data files
    const radarDataArrRaw = parseCsv(radarDataText);
    const technologiesDataArrRaw = parseCsv(technologiesDataText);
    const pratiquesDataArrRaw = parseCsv(pratiquesDataText);
    const orchestrateurDataArrRaw = parseCsv(orchestrateurDataText);
    
    const errors = [];
    
    // 1. Validate and enrich master radar data.
    const radarDataArr = radarDataArrRaw.map(item => {
        const quadrant = quadrantsMap.get(item.quadrant_code);
        if (!quadrant) {
            errors.push({ message: `Dans <code>radar_data.csv</code> pour l'ID <strong>${item.id}</strong>, le quadrant_code "<strong>${item.quadrant_code}</strong>" n'est pas valide.` });
        }
        
        const ring = ringsMap.get(item.ring_code);
        if (!ring) {
             errors.push({ message: `Dans <code>radar_data.csv</code> pour l'ID <strong>${item.id}</strong>, le ring_code "<strong>${item.ring_code}</strong>" n'est pas valide.` });
        }

        const type = typesMap.get(item.type_code);
        if (item.type_code && !type) {
            errors.push({ message: `Dans <code>radar_data.csv</code> pour l'ID <strong>${item.id}</strong>, le type_code "<strong>${item.type_code}</strong>" n'est pas valide.` });
        }

        // Gère les responsables multiples (séparés par des ';') et les transforme en une chaîne lisible.
        const responsable_names = (item.responsable_codes || '')
            .split(';')
            .map(code => code.trim())
            .filter(code => code)
            .map(code => {
                if (!responsablesMap.has(code)) {
                    errors.push({ message: `Dans <code>radar_data.csv</code> pour l'ID <strong>${item.id}</strong>, le responsable_code "<strong>${code}</strong>" n'est pas valide.` });
                    return `Inconnu (${code})`;
                }
                return responsablesMap.get(code)?.name;
            })
            .join(', ');

        return {
            ...item,
            quadrant: quadrant?.name || item.quadrant_code,
            ring: ring?.name || item.ring_code,
            ring_code: ring?.code,
            type: type?.name || item.type_code,
            responsable: responsable_names,
        };
    });

    // 2. Create a lookup map from the enriched master radar data.
    const radarDataMap = new Map(radarDataArr.map(item => [item.id, item]));

    // 3. Validate and enrich the technology usage data.
    const technologiesData = technologiesDataArrRaw.map(usage => {
        const radarInfo = radarDataMap.get(usage.radar_id);
        if (!radarInfo) {
            errors.push({ message: `L'ID <strong>${usage.radar_id}</strong>, référencé dans <code>technologies_data.csv</code>, n'existe pas dans <code>radar_data.csv</code>.` });
        }
        
        const statusInfo = statusesMap.get(usage.status_code);
        if (!statusInfo) {
            errors.push({ message: `Dans <code>technologies_data.csv</code> pour le radar_id <strong>${usage.radar_id}</strong>, le status_code "<strong>${usage.status_code}</strong>" n'est pas valide.` });
        }

        const projectInfo = projectsMap.get(usage.project_code);
        if (usage.project_code && !projectInfo) {
             errors.push({ message: `Dans <code>technologies_data.csv</code> pour le radar_id <strong>${usage.radar_id}</strong>, le project_code "<strong>${usage.project_code}</strong>" n'est pas valide.` });
        }

        return {
            ...(radarInfo || {}),
            ...usage,
            status: statusInfo?.name || usage.status_code,
            status_description: statusInfo?.description,
            status_icon: statusInfo?.icon,
            status_color: statusInfo?.color,
            projectName: projectInfo?.name || usage.project_code,
        };
    });

    // 4. Validate and enrich the practices data.
    const pratiquesData = pratiquesDataArrRaw.map(pratique => {
        const radarInfo = radarDataMap.get(pratique.radar_id);
        if (!radarInfo) {
            errors.push({ message: `L'ID <strong>${pratique.radar_id}</strong>, référencé dans <code>pratiques_data.csv</code>, n'existe pas dans <code>radar_data.csv</code>.` });
        }

        const projectInfo = projectsMap.get(pratique.project_code);
        if (pratique.project_code && !projectInfo) {
            errors.push({ message: `Dans <code>pratiques_data.csv</code> pour le radar_id <strong>${pratique.radar_id}</strong>, le project_code "<strong>${pratique.project_code}</strong>" n'est pas valide.` });
        }
        return { 
            ...(radarInfo || { name: `ID Invalide (${pratique.radar_id})` }),
            ...pratique,
            projectName: projectInfo?.name || pratique.project_code,
        };
    });

    // 5. Validate and enrich orchestrateur data
    const orchestrateurData = orchestrateurDataArrRaw.map(item => {
        const typeInfo = orchestrateurTypesMap.get(item.type_code);
        if (!typeInfo) {
            errors.push({ message: `Dans <code>orchestrateur_data.csv</code> pour la règle <strong>${item.name}</strong>, le type_code "<strong>${item.type_code}</strong>" n'est pas valide.` });
        }
        
        const projectInfo = projectsMap.get(item.project_code);
        if (item.project_code && !projectInfo) {
            errors.push({ message: `Dans <code>orchestrateur_data.csv</code> pour la règle <strong>${item.name}</strong>, le project_code "<strong>${item.project_code}</strong>" n'est pas valide.` });
        }

        return {
            ...item,
            type: typeInfo?.name || item.type_code,
            projectName: projectInfo?.name || item.project_code,
        };
    });


    // 6. Crée une liste unifiée de toutes les squads en combinant les squads de plusieurs fichiers
    // et en supprimant les doublons, pour s'assurer d'avoir la liste complète.
    const squadsFromTech = new Set(technologiesDataArrRaw.map(t => t.squad));
    const squadsFromPratiques = new Set(pratiquesDataArrRaw.map(p => p.squad));
    const squadsFromOrchestrateur = new Set(orchestrateurDataArrRaw.map(o => o.squad));
    const allSquads = [...new Set([...squadsFromTech, ...squadsFromPratiques, ...squadsFromOrchestrateur])].sort();

    return {
        technologiesData,
        pratiquesData,
        orchestrateurData,
        radarData: radarDataArr,
        ringsData: [...ringsMap.values()],
        quadrantsData: [...quadrantsMap.values()],
        typesData: [...typesMap.values()],
        responsablesData: [...responsablesMap.values()],
        statusesData: [...statusesMap.values()],
        projectsData: [...projectsMap.values()],
        orchestrateurTypesData: [...orchestrateurTypesMap.values()],
        allSquads,
        errors
    };
}

/**
 * Espace réservé pour le chargement de données à partir d'une base de données distante via une API backend.
 * @returns {Promise<Object>}
 */
async function loadDataFromDatabase() {
    // This is a placeholder for future implementation.
    // In a real scenario, you would make API calls to a backend service here.
    // Example: const response = await fetch('/api/data');
    // const data = await response.json();
    // return data;
    throw new Error("Le mode de source de données 'database' n'est pas encore implémenté. Il nécessite une API backend pour interroger la source de données.");
}

/**
 * Récupère et parse toutes les données requises en fonction de la configuration de l'application.
 * C'est le point d'entrée principal pour le chargement des données.
 * @param {object} paths - Un objet contenant les chemins vers les répertoires de données.
 * @returns {Promise<Object>} Une promesse qui se résout en un objet contenant toutes les données de l'application.
 */
export async function loadData(paths) {
    const configResponse = await fetch(`${paths.conf}app_config.json`);
    if (!configResponse.ok) {
        throw new Error(`Le fichier de configuration '${paths.conf}app_config.json' est manquant ou invalide.`);
    }
    const config = await configResponse.json();

    switch(config.type) {
        case 'csv':
            return loadDataFromCsv(paths);
        case 'database':
            return loadDataFromDatabase();
        default:
            throw new Error(`Type de source de données inconnu dans app_config.json: ${config.type}`);
    }
}
