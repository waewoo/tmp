/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Gère la logique et le rendu pour la vue "Aperçu".
 * Cela inclut l'initialisation et la mise à jour de tous les graphiques et statistiques de cette page.
 */

let statutChartInstance = null;
let pratiquesChartInstance = null;
let orchestrateurChartInstance = null;
let pratiquesBySquadChartInstance = null;
let orchestrateurBySquadChartInstance = null;
let globalData = null;

/**
 * Récupère la valeur d'une variable CSS depuis le DOM.
 * @param {string} variable - Le nom de la variable CSS (ex: '--color-primary').
 * @returns {string} La valeur de la variable.
 */
function getCssVariable(variable) {
    return getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
}

/**
 * Applique une couleur de bordure et de texte à une carte de statistique en fonction de sa valeur.
 * @param {string} cardId - L'ID de l'élément de la carte.
 * @param {number} value - La valeur numérique (pourcentage) à évaluer.
 */
function setStatCardColor(cardId, value) {
    const card = document.getElementById(cardId);
    const textElement = card.querySelector('p');
    if (!card || !textElement) return;

    let borderColorClass = 'border-sky-500';
    let textColorClass = 'text-sky-600';

    if (value >= 75) {
        borderColorClass = 'border-green-500';
        textColorClass = 'text-green-600';
    } else if (value >= 40) {
        borderColorClass = 'border-yellow-500';
        textColorClass = 'text-yellow-600';
    } else {
        borderColorClass = 'border-red-500';
        textColorClass = 'text-red-600';
    }
    
    // Supprime les anciennes classes de couleur pour éviter les conflits avant d'ajouter les nouvelles.
    card.className = card.className.replace(/border-(sky|green|yellow|red)-500/g, '');
    textElement.className = textElement.className.replace(/text-(sky|green|yellow|red)-600/g, '');
    
    card.classList.add(borderColorClass);
    textElement.classList.add(textColorClass);
}

/**
 * Crée et retourne un élément DOM pour un item de la légende des statuts.
 * @param {object} statusInfo - L'objet de statut avec nom, couleur, etc.
 * @param {number} count - Le nombre d'items pour ce statut.
 * @returns {HTMLElement} L'élément de légende créé.
 */
function createStatusLegendItem(statusInfo, count) {
    const item = document.createElement('div');
    item.className = 'flex items-center p-3 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors duration-200';
    item.dataset.statusName = statusInfo.name;
    item.setAttribute('role', 'button');
    item.setAttribute('tabindex', '0');

    const colorIndicator = document.createElement('span');
    colorIndicator.className = 'w-5 h-5 rounded-md mr-4 flex-shrink-0';
    colorIndicator.style.backgroundColor = statusInfo.color;
    colorIndicator.setAttribute('aria-hidden', 'true');
    
    const textContainer = document.createElement('div');
    textContainer.className = 'flex-grow';
    
    const nameSpan = document.createElement('span');
    nameSpan.className = 'font-semibold text-slate-800';
    nameSpan.textContent = statusInfo.name;
    
    const descriptionP = document.createElement('p');
    descriptionP.className = 'text-sm text-slate-600';
    descriptionP.textContent = statusInfo.description;

    textContainer.append(nameSpan, descriptionP);
    
    const countContainer = document.createElement('div');
    countContainer.className = 'text-right ml-4 flex-shrink-0';
    
    const countSpan = document.createElement('span');
    countSpan.className = 'font-bold text-slate-800 text-xl';
    countSpan.textContent = count;
    
    countContainer.appendChild(countSpan);
    
    item.append(colorIndicator, textContainer, countContainer);

    const clickHandler = () => {
        window.showView('dashboard', { status: statusInfo.name, subView: 'catalogue' });
    };

    item.addEventListener('click', clickHandler);
    item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            clickHandler();
        }
    });
    
    return item;
}


/**
 * Génère une légende HTML personnalisée et plus visible pour le graphique des statuts.
 * @param {string[]} labels - Un tableau des noms de statuts.
 * @param {number[]} data - Un tableau des comptes pour chaque statut.
 * @param {Array<Object>} statusesData - La liste complète des objets de statut pour obtenir les détails.
 */
function renderStatusLegend(labels, data, statusesData) {
    const legendContainer = document.getElementById('apercu-status-legend');
    if (!legendContainer) return;

    legendContainer.innerHTML = '';
    const fragment = document.createDocumentFragment();

    labels.forEach((label, index) => {
        const statusInfo = statusesData.find(s => s.name === label);
        if (statusInfo) {
            const legendItem = createStatusLegendItem(statusInfo, data[index]);
            fragment.appendChild(legendItem);
        }
    });

    legendContainer.appendChild(fragment);
}

/**
 * Met à jour le graphique des statuts avec des données filtrées.
 */
function updateStatusChart() {
    if (!globalData || !statutChartInstance) return;

    const { technologiesData, statusesData } = globalData;
    const squadFilter = document.getElementById('apercu-squad-filter');
    const projectFilter = document.getElementById('apercu-project-filter');
    const selectedSquad = squadFilter.value;
    const selectedProject = projectFilter.value;

    const filteredTechData = technologiesData.filter(t => 
        (selectedSquad === 'all' || t.squad === selectedSquad) &&
        (selectedProject === 'all' || t.project_code === selectedProject)
    );

    const statusCounts = filteredTechData.reduce((acc, item) => {
        acc[item.status] = (acc[item.status] || 0) + 1;
        return acc;
    }, {});
    
    // Définit un ordre fixe pour les statuts afin d'assurer une cohérence visuelle dans le graphique.
    const statusOrder = ['ref', 'emer', 'risk', 'eol', 'shadow', 'conf'];
    
    const chartLabels = statusOrder
        .map(code => statusesData.find(s => s.code === code)?.name)
        .filter(name => name && statusCounts[name] > 0); // Affiche seulement les statuts qui ont des données

    const chartData = chartLabels.map(name => statusCounts[name] || 0);
    const chartColors = chartLabels.map(name => {
        return statusesData.find(s => s.name === name)?.color || getCssVariable('--color-text-subtle');
    });
    
    renderStatusLegend(chartLabels, chartData, statusesData);

    statutChartInstance.data.labels = chartLabels;
    statutChartInstance.data.datasets[0].data = chartData;
    statutChartInstance.data.datasets[0].backgroundColor = chartColors;
    statutChartInstance.update();
}

/**
 * Initialise le graphique en anneau (doughnut) des statuts.
 */
function initStatusChart() {
    const statutCtx = document.getElementById('statutChart').getContext('2d');
    statutChartInstance = new window.Chart(statutCtx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [],
                borderColor: getCssVariable('--color-surface'),
                borderWidth: 3,
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true,
            cutout: '60%',
            onClick: (evt, elements) => {
                if (elements.length > 0) {
                    const clickedLabel = statutChartInstance.data.labels[elements[0].index];
                    window.showView('dashboard', { status: clickedLabel, subView: 'catalogue' });
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) { label += ': '; }
                            const count = context.parsed;
                            const sum = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = sum > 0 ? ((count / sum) * 100).toFixed(1) : 0;
                            label += `${count} (${percentage}%)`;
                            return label;
                        }
                    }
                },
                datalabels: {
                    formatter: (value, ctx) => {
                        const sum = ctx.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
                        const percentage = sum > 0 ? (value / sum * 100) : 0;
                        return percentage > 5 ? Math.round(percentage) + '%' : '';
                    },
                    color: '#fff',
                    font: { weight: 'bold', size: 14 },
                    textShadowBlur: 2,
                    textShadowColor: 'rgba(0,0,0,0.5)'
                }
            }
        },
        plugins: [window.ChartDataLabels],
    });
}

/**
 * Met à jour le graphique à barres du taux d'adoption des pratiques.
 */
function updatePratiquesChart() {
    if (!globalData || !pratiquesChartInstance) return;
    const projectFilter = document.getElementById('apercu-project-filter').value;
    const { pratiquesData, allSquads } = globalData;
    
    const filteredData = pratiquesData.filter(p => projectFilter === 'all' || p.project_code === projectFilter);

    const matrixData = filteredData.reduce((acc, item) => {
        const key = item.radar_id || item.name;
        if (!acc[key]) acc[key] = {};
        acc[key][item.squad] = item.status;
        return acc;
    }, {});

    const adoptionRates = [];
    const practiceLabels = [];
    for (const pratique in matrixData) {
        const results = matrixData[pratique];
        const ouiCount = Object.values(results).filter(v => v === 'Oui').length;
        const partielCount = Object.values(results).filter(v => v === 'Partiel').length;
        // Règle métier : une adoption "Partielle" compte pour la moitié d'une adoption "Oui".
        const adoptionRate = ((ouiCount + partielCount * 0.5) / allSquads.length) * 100;
        adoptionRates.push(adoptionRate);
        practiceLabels.push(globalData.radarData.find(r => r.id === pratique)?.name || pratique);
    }
    
    const globalAvgContainer = document.getElementById('pratiques-global-avg-stat');
    if (globalAvgContainer) {
        const totalRate = adoptionRates.reduce((sum, rate) => sum + rate, 0);
        const average = adoptionRates.length > 0 ? totalRate / adoptionRates.length : 0;
        globalAvgContainer.textContent = `${Math.round(average)}%`;
        setStatCardColor('pratiques-stat-card', average);
    }
    
    const colors = {
        success: getCssVariable('--color-success'),
        warning: getCssVariable('--color-warning'),
        danger: getCssVariable('--color-danger')
    };

    pratiquesChartInstance.data.labels = practiceLabels;
    pratiquesChartInstance.data.datasets[0].data = adoptionRates;
    pratiquesChartInstance.data.datasets[0].backgroundColor = adoptionRates.map(rate => rate >= 75 ? colors.success : (rate >= 40 ? colors.warning : colors.danger));
    pratiquesChartInstance.update();
}

/**
 * Initialise le graphique à barres des pratiques.
 */
function initPratiquesChart() {
    const pratiquesCtx = document.getElementById('pratiquesChart').getContext('2d');
    pratiquesChartInstance = new window.Chart(pratiquesCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Taux d\'Adoption',
                data: [],
                backgroundColor: [],
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            responsive: true,
            scales: { x: { max: 100, ticks: { callback: value => value + '%' } } },
            plugins: { 
                legend: { display: false }
            }
        }
    });
}

/**
 * Met à jour le graphique à barres du taux de respect des règles de l'orchestrateur.
 */
function updateOrchestrateurChart() {
    if (!globalData || !orchestrateurChartInstance) return;
    const projectFilter = document.getElementById('apercu-project-filter').value;
    const { orchestrateurData, allSquads } = globalData;

    const filteredData = orchestrateurData.filter(o => projectFilter === 'all' || o.project_code === projectFilter);

    const matrixData = filteredData.reduce((acc, item) => {
        const key = item.name;
        if (!acc[key]) acc[key] = {};
        acc[key][item.squad] = item.status;
        return acc;
    }, {});

    const adoptionRates = [];
    const ruleLabels = [];
    for (const rule in matrixData) {
        const results = matrixData[rule];
        const ouiCount = Object.values(results).filter(v => v === 'Oui').length;
        const partielCount = Object.values(results).filter(v => v === 'Partiel').length;
        // Règle métier : un respect "Partiel" compte pour la moitié d'un respect "Oui".
        const adoptionRate = ((ouiCount + partielCount * 0.5) / allSquads.length) * 100;
        adoptionRates.push(adoptionRate);
        ruleLabels.push(rule);
    }

    const globalAvgContainer = document.getElementById('orchestrateur-global-avg-stat');
    if (globalAvgContainer) {
        const totalRate = adoptionRates.reduce((sum, rate) => sum + rate, 0);
        const average = adoptionRates.length > 0 ? totalRate / adoptionRates.length : 0;
        globalAvgContainer.textContent = `${Math.round(average)}%`;
        setStatCardColor('orchestrateur-stat-card', average);
    }
    
    const colors = {
        success: getCssVariable('--color-success'),
        warning: getCssVariable('--color-warning'),
        danger: getCssVariable('--color-danger')
    };
    
    orchestrateurChartInstance.data.labels = ruleLabels;
    orchestrateurChartInstance.data.datasets[0].data = adoptionRates;
    orchestrateurChartInstance.data.datasets[0].backgroundColor = adoptionRates.map(rate => rate >= 75 ? colors.success : (rate >= 40 ? colors.warning : colors.danger));
    orchestrateurChartInstance.update();
}

/**
 * Initialise le graphique à barres de l'orchestrateur.
 */
function initOrchestrateurChart() {
    const orchestrateurCtx = document.getElementById('orchestrateurChart').getContext('2d');
    orchestrateurChartInstance = new window.Chart(orchestrateurCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Taux de Conformité',
                data: [],
                backgroundColor: [],
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            responsive: true,
            scales: { x: { max: 100, ticks: { callback: value => value + '%' } } },
            plugins: { 
                legend: { display: false }
            }
        }
    });
}

/**
 * Calcule et affiche le taux global de technologies ayant le statut "Référence".
 */
function calculateTechRefRate() {
    const { technologiesData } = globalData;
    const projectFilter = document.getElementById('apercu-project-filter').value;
    const statContainer = document.getElementById('tech-ref-avg-stat');
    if (!statContainer) return;

    const refStatusCode = 'ref';
    
    const filteredData = technologiesData.filter(t => projectFilter === 'all' || t.project_code === projectFilter);
    
    if (filteredData.length === 0) {
        statContainer.textContent = '0%';
        setStatCardColor('tech-ref-stat-card', 0);
        return;
    }
    
    const refCount = filteredData.filter(t => t.status_code === refStatusCode).length;
    const totalCount = filteredData.length;
    const rate = totalCount > 0 ? (refCount / totalCount) * 100 : 0;

    statContainer.textContent = `${Math.round(rate)}%`;
    setStatCardColor('tech-ref-stat-card', rate);
}

/**
 * Met à jour un graphique à barres montrant des taux par squad.
 * @param {Chart} chartInstance - L'instance du graphique Chart.js à mettre à jour.
 * @param {Array<Object>} data - Les données à analyser (pratiques ou orchestrateur).
 * @param {string[]} allSquads - La liste de toutes les squads pour le calcul du taux.
 * @param {number} totalItems - Le nombre total d'items de référence pour le calcul du taux.
 */
function updateSquadBarChart(chartInstance, data, allSquads, totalItems) {
    if (!chartInstance) return;
    const projectFilter = document.getElementById('apercu-project-filter').value;

    const filteredData = data.filter(item => projectFilter === 'all' || item.project_code === projectFilter);

    const squadRates = allSquads.map(squad => {
        const squadData = filteredData.filter(item => item.squad === squad);
        const ouiCount = squadData.filter(item => item.status === 'Oui').length;
        const partielCount = squadData.filter(item => item.status === 'Partiel').length;
        
        // Le dénominateur pour le taux doit être le nombre de pratiques/règles pertinentes pour le filtre actuel.
        // Par exemple, si on filtre sur un projet, on ne compte que les pratiques utilisées dans ce projet.
        const relevantItems = new Set(filteredData.map(item => item.name || item.id));
        const totalItemsForRate = relevantItems.size;

        const rate = totalItemsForRate > 0 ? ((ouiCount + partielCount * 0.5) / totalItemsForRate) * 100 : 0;
        return { squad, rate };
    }).sort((a, b) => b.rate - a.rate);

    const labels = squadRates.map(item => item.squad);
    const rates = squadRates.map(item => item.rate);

    const colors = {
        success: getCssVariable('--color-success'),
        warning: getCssVariable('--color-warning'),
        danger: getCssVariable('--color-danger')
    };
    
    chartInstance.data.labels = labels;
    chartInstance.data.datasets[0].data = rates;
    chartInstance.data.datasets[0].backgroundColor = rates.map(rate => rate >= 75 ? colors.success : (rate >= 40 ? colors.warning : colors.danger));
    chartInstance.update();
}

/**
 * Crée une nouvelle instance de graphique à barres pour l'affichage par squad.
 * @param {string} canvasId - L'ID de l'élément canvas.
 * @param {string} label - Le label pour le jeu de données du graphique.
 * @returns {Chart} La nouvelle instance du graphique Chart.js.
 */
function createSquadBarChart(canvasId, label) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new window.Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: label,
                data: [],
                backgroundColor: [],
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
            responsive: true,
            scales: { x: { min: 0, max: 100, ticks: { callback: value => value + '%' } } },
            plugins: { 
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (context) => `${context.raw.toFixed(1)}%`
                    }
                }
            }
        }
    });
}

/**
 * Met à jour tous les graphiques de la page Aperçu.
 */
function updateAllCharts() {
    updateStatusChart();
    updatePratiquesChart();
    updateOrchestrateurChart();
    calculateTechRefRate();
    
    const { pratiquesData, allSquads: allSquadsPratiques } = globalData;
    const totalPractices = new Set(pratiquesData.map(p => p.radar_id)).size;
    updateSquadBarChart(pratiquesBySquadChartInstance, pratiquesData, allSquadsPratiques, totalPractices);

    const { orchestrateurData, allSquads: allSquadsOrchestrateur } = globalData;
    const totalRules = new Set(orchestrateurData.map(p => p.name)).size;
    updateSquadBarChart(orchestrateurBySquadChartInstance, orchestrateurData, allSquadsOrchestrateur, totalRules);
}

/**
 * Point d'entrée pour initialiser la vue "Aperçu".
 * @param {object} data - L'objet de données global de l'application.
 */
export function initApercu(data) {
    globalData = data;

    if (!window.Chart || !window.ChartDataLabels) {
        console.error("Fatal Error: Chart.js or its datalabels plugin has not loaded.");
        return;
    }
    
    const squadFilter = document.getElementById('apercu-squad-filter');
    const projectFilter = document.getElementById('apercu-project-filter');

    if (squadFilter.options.length <= 1) {
        const squadsWithTech = [...new Set(data.technologiesData.map(t => t.squad))].sort();
        squadsWithTech.forEach(squad => {
            const option = document.createElement('option');
            option.value = squad;
            option.textContent = squad;
            squadFilter.appendChild(option);
        });
    }
    
    if (projectFilter.options.length <= 1) {
        data.projectsData.forEach(project => {
            const option = document.createElement('option');
            option.value = project.code;
            option.textContent = project.name;
            projectFilter.appendChild(option);
        });
    }
    
    [squadFilter, projectFilter].forEach(filter => {
        if (!filter.dataset.listenerAttached) {
            filter.addEventListener('change', updateAllCharts);
            filter.dataset.listenerAttached = 'true';
        }
    });
    
    if (!statutChartInstance) initStatusChart();
    if (!pratiquesChartInstance) initPratiquesChart();
    if (!orchestrateurChartInstance) initOrchestrateurChart();
    if (!pratiquesBySquadChartInstance) {
        pratiquesBySquadChartInstance = createSquadBarChart('pratiquesBySquadChart', "Taux d'adoption");
    }
    if (!orchestrateurBySquadChartInstance) {
        orchestrateurBySquadChartInstance = createSquadBarChart('orchestrateurBySquadChart', "Taux de respect");
    }
    
    updateAllCharts();
}
