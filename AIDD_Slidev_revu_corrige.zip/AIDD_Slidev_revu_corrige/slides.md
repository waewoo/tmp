---
theme: default
title: AI-Driven Dev (AIDD) — architecture et utilisation
aspectRatio: 16/9
canvasWidth: 1600
colorSchema: light
selectable: true
---

<!-- Diapositive 01 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-01.svg" alt="Fond vectoriel diapositive 1" />
  <div class="pptx-text" data-shape="1-1" style="left:918px;top:53.1px;width:580.5px;height:49.5px;padding:2.7px 2.7px;font-size:20px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Sources : documentation publique AIDD — novembre 2026</span></div>
  <div class="pptx-text" data-shape="1-2" style="left:94.5px;top:312.3px;width:1404px;height:117px;padding:2.7px 2.7px;font-size:87.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">AI-Driven Dev (AIDD)</span></div>
  <div class="pptx-text" data-shape="1-3" style="left:92.7px;top:457.2px;width:1368px;height:157.5px;padding:2.7px 2.7px;font-size:62.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Architecture, installation et utilisation
dans un projet DevOps</span></div>
  <div class="pptx-text" data-shape="1-4" style="left:95.4px;top:647.1px;width:1395px;height:52.2px;padding:2.7px 2.7px;font-size:31.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Guide technique pour développeurs, Tech Leads et DevOps</span></div>
</div>

---

<!-- Diapositive 02 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-02.svg" alt="Fond vectoriel diapositive 2" />
  <div class="pptx-text" data-shape="2-1" style="left:50.4px;top:28.8px;width:1512px;height:135px;padding:2.7px 2.7px;font-size:36.25px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">FRAMEWORK D’ORCHESTRATION DU SOFTWARE DEVELOPMENT LIFE
CYCLE (SDLC) POUR LES ASSISTANTS IA (CLAUDE CODE, CURSOR,
COPILOT, CODEX, KILO CODE, OPENCODE)</span></div>
  <div class="pptx-text" data-shape="2-2" style="left:64.8px;top:222.3px;width:684px;height:51.3px;padding:2.7px 2.7px;font-size:38.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">CE QU’EST AIDD</span></div>
  <div class="pptx-text" data-shape="2-3" style="left:714.6px;top:217.8px;width:60.3px;height:64.8px;padding:2.7px 2.7px;font-size:52.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">✓</span></div>
  <div class="pptx-text" data-shape="2-4" style="left:815.4px;top:222.3px;width:658.8px;height:51.3px;padding:2.7px 2.7px;font-size:38.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">CE QUE N’EST PAS AIDD</span></div>
  <div class="pptx-text" data-shape="2-5" style="left:1488.6px;top:217.8px;width:54px;height:64.8px;padding:2.7px 2.7px;font-size:52.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">×</span></div>
  <div class="pptx-text" data-shape="2-6" style="left:100.8px;top:302.4px;width:671.4px;height:133.2px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Génération et maintien du contexte projet
(mémoire persistante).</span></div>
  <div class="pptx-text" data-shape="2-7" style="left:100.8px;top:438.3px;width:671.4px;height:133.2px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Exécution de workflows de développement
standardisés (cadrage, implémentation,
tests, revue).</span></div>
  <div class="pptx-text" data-shape="2-8" style="left:100.8px;top:574.2px;width:671.4px;height:133.2px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Gestion automatisée des opérations Git
(commits atomiques, Pull/Merge Requests).</span></div>
  <div class="pptx-text" data-shape="2-9" style="left:855px;top:301.5px;width:656.1px;height:125.1px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">L’IA exécute un plan, mais l’ingénieur reste
le décideur et responsable ultime.</span></div>
  <div class="pptx-text" data-shape="2-10" style="left:855px;top:429.3px;width:656.1px;height:125.1px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">La responsabilité humaine et la CI restent
essentielles, même si le mode auto n’impose pas
de pauses à chaque étape. Le mode interactif
prévoit des pauses (contrat, plan, résultat).</span></div>
  <div class="pptx-text" data-shape="2-11" style="left:855px;top:557.1px;width:656.1px;height:125.1px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Le framework est contraint par les limites
de contexte (tokens) du modèle LLM.</span></div>
  <div class="pptx-text" data-shape="2-12" style="left:855px;top:684.9px;width:656.1px;height:125.1px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Il ne remplace pas les pipelines de validation
de la CI finale.</span></div>
</div>

---

<!-- Diapositive 03 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-03.svg" alt="Fond vectoriel diapositive 3" />
  <div class="pptx-text" data-shape="3-1" style="left:135px;top:59.4px;width:1332px;height:76.5px;padding:2.7px 2.7px;font-size:70px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">GLOSSAIRE TECHNIQUE</span></div>
  <div class="pptx-text" data-shape="3-2" style="left:108.9px;top:234.9px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣</span></div>
  <div class="pptx-text" data-shape="3-3" style="left:192.6px;top:231.3px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Plugin</span></div>
  <div class="pptx-text" data-shape="3-4" style="left:108px;top:316.8px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Paquet installable
regroupant des capacités
sur un domaine.</span></div>
  <div class="pptx-text" data-shape="3-5" style="left:610.2px;top:234.9px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">⚙</span></div>
  <div class="pptx-text" data-shape="3-6" style="left:693.9px;top:231.3px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Skill</span></div>
  <div class="pptx-text" data-shape="3-7" style="left:609.3px;top:316.8px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Workflow déclenché par
l’utilisateur ou une
demande appropriée.</span></div>
  <div class="pptx-text" data-shape="3-8" style="left:1111.5px;top:234.9px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">➤</span></div>
  <div class="pptx-text" data-shape="3-9" style="left:1195.2px;top:231.3px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Action</span></div>
  <div class="pptx-text" data-shape="3-10" style="left:1110.6px;top:316.8px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Étape interne d’un skill,
non invoquée
directement.</span></div>
  <div class="pptx-text" data-shape="3-11" style="left:108.9px;top:546.3px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">◇</span></div>
  <div class="pptx-text" data-shape="3-12" style="left:192.6px;top:542.7px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Orchestrateur</span></div>
  <div class="pptx-text" data-shape="3-13" style="left:108px;top:628.2px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Skill coordonnant d’autres
skills.</span></div>
  <div class="pptx-text" data-shape="3-14" style="left:610.2px;top:546.3px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤</span></div>
  <div class="pptx-text" data-shape="3-15" style="left:693.9px;top:542.7px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Sous-agent</span></div>
  <div class="pptx-text" data-shape="3-16" style="left:609.3px;top:628.2px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Agent spécialisé opérant
dans un contexte isolé et
retournant un résultat.</span></div>
  <div class="pptx-text" data-shape="3-17" style="left:1111.5px;top:546.3px;width:90px;height:75.6px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▦</span></div>
  <div class="pptx-text" data-shape="3-18" style="left:1195.2px;top:542.7px;width:308.7px;height:58.5px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#112A43;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Hook</span></div>
  <div class="pptx-text" data-shape="3-19" style="left:1110.6px;top:628.2px;width:405.9px;height:114.3px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Script déclenché lors
d’un événement de session,
distinct d’un hook Git.</span></div>
</div>

---

<!-- Diapositive 04 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-04.svg" alt="Fond vectoriel diapositive 4" />
  <div class="pptx-text" data-shape="4-1" style="left:72px;top:48.6px;width:1431px;height:68.4px;padding:2.7px 2.7px;font-size:58.75px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Architecture &amp; Plugins AIDD</span></div>
  <div class="pptx-text" data-shape="4-2" style="left:186.3px;top:175.5px;width:225.9px;height:39.6px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Utilisateur ]</span></div>
  <div class="pptx-text" data-shape="4-3" style="left:521.1px;top:175.5px;width:207.9px;height:39.6px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Skill ]</span></div>
  <div class="pptx-text" data-shape="4-4" style="left:838.8px;top:175.5px;width:216.9px;height:39.6px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Action ]</span></div>
  <div class="pptx-text" data-shape="4-5" style="left:1180.8px;top:175.5px;width:252.9px;height:39.6px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Résultat / Fichier ]</span></div>
  <div class="pptx-text" data-shape="4-6" style="left:253.8px;top:307.8px;width:265.5px;height:54.9px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Orchestrateur ]</span></div>
  <div class="pptx-text" data-shape="4-7" style="left:682.2px;top:283.5px;width:109.8px;height:40.5px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Skill ]</span></div>
  <div class="pptx-text" data-shape="4-8" style="left:682.2px;top:342.9px;width:109.8px;height:40.5px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Skill ]</span></div>
  <div class="pptx-text" data-shape="4-9" style="left:682.2px;top:402.3px;width:109.8px;height:40.5px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Skill ]</span></div>
  <div class="pptx-text" data-shape="4-10" style="left:1117.8px;top:314.1px;width:204.3px;height:54.9px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Sous-agent ]</span></div>
  <div class="pptx-text" data-shape="4-11" style="left:837px;top:311.4px;width:270px;height:24.3px;padding:2.7px 2.7px;font-size:20px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">délègue un travail isolé au</span></div>
  <div class="pptx-text" data-shape="4-12" style="left:70.2px;top:429.3px;width:900px;height:44.1px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Sélection des plugins principaux</span></div>
  <div class="pptx-text" data-shape="4-13" style="left:77.4px;top:514.8px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">◉</span></div>
  <div class="pptx-text" data-shape="4-14" style="left:174.6px;top:504.9px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-context</span></div>
  <div class="pptx-text" data-shape="4-15" style="left:174.6px;top:542.7px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Connaissance projet, mémoire
et apprentissage. Gestion
du contexte durable.</span></div>
  <div class="pptx-text" data-shape="4-16" style="left:579.6px;top:514.8px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">&lt;/&gt;</span></div>
  <div class="pptx-text" data-shape="4-17" style="left:676.8px;top:504.9px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-dev</span></div>
  <div class="pptx-text" data-shape="4-18" style="left:676.8px;top:542.7px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Transformation du code (plan,
construction, assertion, revue,
refactoring).</span></div>
  <div class="pptx-text" data-shape="4-19" style="left:1081.8px;top:514.8px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤</span></div>
  <div class="pptx-text" data-shape="4-20" style="left:1179px;top:504.9px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-pm</span></div>
  <div class="pptx-text" data-shape="4-21" style="left:1179px;top:542.7px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Gestion produit (briefs, epics,
specs, defects, backlog).</span></div>
  <div class="pptx-text" data-shape="4-22" style="left:77.4px;top:669.6px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">⑂</span></div>
  <div class="pptx-text" data-shape="4-23" style="left:174.6px;top:659.7px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-vcs</span></div>
  <div class="pptx-text" data-shape="4-24" style="left:174.6px;top:697.5px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Opérations Git (commits
atomiques, PR/MR, tags).</span></div>
  <div class="pptx-text" data-shape="4-25" style="left:579.6px;top:669.6px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">⌕</span></div>
  <div class="pptx-text" data-shape="4-26" style="left:676.8px;top:659.7px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-refine</span></div>
  <div class="pptx-text" data-shape="4-27" style="left:676.8px;top:697.5px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Réflexion critique : brainstorm,
challenge, vérification des faits
et angles morts.</span></div>
  <div class="pptx-text" data-shape="4-28" style="left:1081.8px;top:669.6px;width:83.7px;height:69.3px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#B68568;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">⚙</span></div>
  <div class="pptx-text" data-shape="4-29" style="left:1179px;top:659.7px;width:333px;height:39.6px;padding:2.7px 2.7px;font-size:27.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-orchestrator</span></div>
  <div class="pptx-text" data-shape="4-30" style="left:1179px;top:697.5px;width:337.5px;height:78.3px;padding:2.7px 2.7px;font-size:22.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Flux SDLC de bout en bout et
gestion de backlog.</span></div>
</div>

---

<!-- Diapositive 05 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-05.svg" alt="Fond vectoriel diapositive 5" />
  <div class="pptx-text" data-shape="5-1" style="left:72px;top:181.8px;width:437.4px;height:63px;padding:2.7px 2.7px;font-size:38.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣ aidd_docs/</span></div>
  <div class="pptx-text" data-shape="5-2" style="left:135px;top:245.7px;width:387px;height:55.8px;padding:2.7px 2.7px;font-size:36.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣ memory/</span></div>
  <div class="pptx-text" data-shape="5-3" style="left:213.3px;top:366.3px;width:418.5px;height:55.8px;padding:2.7px 2.7px;font-size:30px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤ architecture.md</span></div>
  <div class="pptx-text" data-shape="5-4" style="left:213.3px;top:459.9px;width:418.5px;height:55.8px;padding:2.7px 2.7px;font-size:30px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤ codebase-map.md</span></div>
  <div class="pptx-text" data-shape="5-5" style="left:213.3px;top:555.3px;width:418.5px;height:55.8px;padding:2.7px 2.7px;font-size:30px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤ coding-assertions.md</span></div>
  <div class="pptx-text" data-shape="5-6" style="left:213.3px;top:650.7px;width:418.5px;height:55.8px;padding:2.7px 2.7px;font-size:30px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣ internal/</span></div>
  <div class="pptx-text" data-shape="5-7" style="left:213.3px;top:746.1px;width:418.5px;height:55.8px;padding:2.7px 2.7px;font-size:30px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣ external/</span></div>
  <div class="pptx-text" data-shape="5-8" style="left:815.4px;top:135px;width:207px;height:94.5px;padding:2.7px 2.7px;font-size:78.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▣</span></div>
  <div class="pptx-text" data-shape="5-9" style="left:792.9px;top:247.5px;width:252px;height:82.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">MÉMOIRE</span></div>
  <div class="pptx-text" data-shape="5-10" style="left:1086.3px;top:135px;width:207px;height:94.5px;padding:2.7px 2.7px;font-size:78.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤</span></div>
  <div class="pptx-text" data-shape="5-11" style="left:1063.8px;top:247.5px;width:252px;height:82.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">FICHIER DE
CONTEXTE</span></div>
  <div class="pptx-text" data-shape="5-12" style="left:1354.5px;top:135px;width:207px;height:94.5px;padding:2.7px 2.7px;font-size:78.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">◎</span></div>
  <div class="pptx-text" data-shape="5-13" style="left:1332px;top:247.5px;width:252px;height:82.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">ASSISTANT IA</span></div>
  <div class="pptx-text" data-shape="5-14" style="left:1051.2px;top:333px;width:342px;height:79.2px;padding:2.7px 2.7px;font-size:27.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">(AGENTS.md /
CLAUDE.md)</span></div>
  <div class="pptx-text" data-shape="5-15" style="left:821.7px;top:478.8px;width:666px;height:54.9px;padding:2.7px 2.7px;font-size:35px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Rôle des Hooks (SessionStart / Stop)</span></div>
  <div class="pptx-text" data-shape="5-16" style="left:873px;top:567px;width:619.2px;height:114.3px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Maintiennent le référencement de la
mémoire dans AGENTS.md ou CLAUDE.md.</span></div>
  <div class="pptx-text" data-shape="5-17" style="left:873px;top:684px;width:619.2px;height:114.3px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Vérifient l’intégrité et certains changements,
sans charger toute la mémoire.</span></div>
</div>

---

<!-- Diapositive 06 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-06.svg" alt="Fond vectoriel diapositive 6" />
  <div class="pptx-text" data-shape="6-1" style="left:64.8px;top:56.7px;width:1467px;height:72px;padding:2.7px 2.7px;font-size:52.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Installation d’AIDD : CLI officielle ou Makefile d’intégration</span></div>
  <div class="pptx-text" data-shape="6-2" style="left:83.7px;top:229.5px;width:667.8px;height:71.1px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">▣  1. Installation officielle</span></div>
  <div class="pptx-text" data-shape="6-3" style="left:828px;top:229.5px;width:670.5px;height:71.1px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">▤  2. Intégration locale par Makefile</span></div>
  <div class="pptx-text" data-shape="6-4" style="left:88.2px;top:333px;width:666px;height:90px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Prérequis : Node.js 22.12 minimum et
assistant IA compatible.</span></div>
  <div class="pptx-text" data-shape="6-5" style="left:823.5px;top:331.2px;width:663.3px;height:121.5px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Un environnement peut proposer des
Makefiles pour standardiser l’installation
et la configuration d’AIDD.</span></div>
  <div class="pptx-text" data-shape="6-6" style="left:91.8px;top:454.5px;width:657.9px;height:62.1px;padding:2.7px 2.7px;font-size:26.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">npx @ai-driven-dev/cli@latest setup</span></div>
  <div class="pptx-text" data-shape="6-7" style="left:91.8px;top:547.2px;width:657.9px;height:62.1px;padding:2.7px 2.7px;font-size:26.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">npx @ai-driven-dev/cli@latest doctor</span></div>
  <div class="pptx-text" data-shape="6-8" style="left:864px;top:487.8px;width:599.4px;height:104.4px;padding:2.7px 2.7px;font-size:27.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">« Commandes spécifiques à
l’environnement : à compléter »</span></div>
  <div class="pptx-text" data-shape="6-9" style="left:220.5px;top:739.8px;width:1161px;height:82.8px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Après installation : préparer le contexte du projet
(voir diapositive suivante)</span></div>
</div>

---

<!-- Diapositive 07 : parcours remaquetté, composants HTML/SVG modifiables -->
<div class="pptx-canvas aidd-onboarding">
  <h1>Première utilisation dans un projet existant</h1>
  <div class="ob-grid">
    <article class="ob-step" style="--ob-color:#192F46">
      <div class="ob-arrow"><svg class="ob-chevron-bg" viewBox="0 0 360 150" preserveAspectRatio="none"><polygon points="0,0 300,0 360,75 300,150 0,150" fill="#192F46"/></svg><span class="ob-no">01</span><span class="ob-icon"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="#FFFFFF" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M5 12h14l5 6h19v22H5z"/><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M5 18h38"/></svg></span></div>
      <h2>OUVRIR LE PROJET</h2>
      <p>Ouvrir le dépôt dans un assistant IA compatible, à la racine du projet.</p>
      <div class="ob-command-empty"></div>
      
    </article>
    <article class="ob-step" style="--ob-color:#176B77">
      <div class="ob-arrow"><svg class="ob-chevron-bg" viewBox="0 0 360 150" preserveAspectRatio="none"><polygon points="0,0 300,0 360,75 300,150 0,150" fill="#176B77"/></svg><span class="ob-no">02</span><span class="ob-icon"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="#FFFFFF" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M5 11l13-5 13 5 12-5v31l-12 5-13-5-13 5z"/><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M18 6v31M31 11v31"/><circle fill="none" stroke="#FFFFFF" stroke-width="2.7" cx="25" cy="22" r="4"/></svg></span></div>
      <h2>DÉCOUVRIR AIDD</h2>
      <p>Utiliser facultativement le guide pour identifier les prochaines actions.</p>
      <code class="ob-command">/aidd-context:00-onboard</code>
      
    </article>
    <article class="ob-step" style="--ob-color:#2B8994">
      <div class="ob-arrow"><svg class="ob-chevron-bg" viewBox="0 0 360 150" preserveAspectRatio="none"><polygon points="0,0 300,0 360,75 300,150 0,150" fill="#2B8994"/></svg><span class="ob-no">03</span><span class="ob-icon"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="#FFFFFF" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M24 11c-2-8-17-6-16 5-6 5-3 14 2 16-1 9 13 11 14 3M24 11c2-8 17-6 16 5 6 5 3 14-2 16 1 9-13 11-14 3M24 11v24M16 18l8 6 8-6M16 30l8-6 8 6"/></svg></span></div>
      <h2>INITIALISER LA MÉMOIRE</h2>
      <p>Créer ou actualiser le contexte durable dans <code>aidd_docs/memory/</code>.</p>
      <code class="ob-command">/aidd-context:02-project-memory</code>
      <small>Mémoire actualisée selon les besoins, pas à chaque session.</small>
    </article>
    <article class="ob-step" style="--ob-color:#3A9FA8">
      <div class="ob-arrow"><svg class="ob-chevron-bg" viewBox="0 0 360 150" preserveAspectRatio="none"><polygon points="0,0 300,0 360,75 300,150 0,150" fill="#3A9FA8"/></svg><span class="ob-no">04</span><span class="ob-icon"><svg viewBox="0 0 48 48" aria-hidden="true" fill="none" stroke="#FFFFFF" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M19 31l-6-6c2-10 12-18 27-18 0 15-8 25-18 27z"/><circle fill="none" stroke="#FFFFFF" stroke-width="2.7" cx="30" cy="17" r="4"/><path fill="none" stroke="#FFFFFF" stroke-width="2.7" d="M14 27l-7 2-3 9 12-5M22 35l-2 8-9 2 3-12"/></svg></span></div>
      <h2>COMMENCER À TRAVAILLER</h2>
      <p>Choisir un skill individuel ou le workflow SDLC selon le besoin.</p>
      <div class="ob-command-empty"></div>
      
    </article>
  </div>
</div>
---

<!-- Diapositive 08 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-08.svg" alt="Fond vectoriel diapositive 8" />
  <div class="pptx-text" data-shape="8-1" style="left:60.3px;top:37.8px;width:1476px;height:65.7px;padding:2.7px 2.7px;font-size:52.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">AIDD : comment lancer une tâche ou un développement ?</span></div>
  <div class="pptx-text" data-shape="8-2" style="left:66.6px;top:156.6px;width:696.6px;height:70.2px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">1. SKILL PONCTUEL</span></div>
  <div class="pptx-text" data-shape="8-3" style="left:89.1px;top:244.8px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:05-review</span></div>
  <div class="pptx-text" data-shape="8-4" style="left:81px;top:302.4px;width:667.8px;height:81px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Exécuter une action précise, ici une revue de code.</span></div>
  <div class="pptx-text" data-shape="8-5" style="left:81px;top:425.7px;width:667.8px;height:33.3px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Pilotage : le développeur choisit le skill.</span></div>
  <div class="pptx-text" data-shape="8-6" style="left:836.1px;top:156.6px;width:696.6px;height:70.2px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">2. ENCHAÎNEMENT MANUEL</span></div>
  <div class="pptx-text" data-shape="8-7" style="left:858.6px;top:244.8px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:01-plan</span></div>
  <div class="pptx-text" data-shape="8-8" style="left:858.6px;top:295.2px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:02-implement</span></div>
  <div class="pptx-text" data-shape="8-9" style="left:858.6px;top:345.6px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:03-assert</span></div>
  <div class="pptx-text" data-shape="8-10" style="left:850.5px;top:397px;width:667.8px;height:36px;padding:2.7px 2.7px;font-size:21px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Le développeur enchaîne lui-même les trois skills.</span></div>
  <div class="pptx-text" data-shape="8-11" style="left:850.5px;top:440px;width:667.8px;height:33.3px;padding:2.7px 2.7px;font-size:20px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Pilotage : manuel, hors orchestrateur SDLC.</span></div>
  <div class="pptx-text" data-shape="8-12" style="left:66.6px;top:503.1px;width:696.6px;height:70.2px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">3. SDLC AUTOMATIQUE</span></div>
  <div class="pptx-text" data-shape="8-13" style="left:89.1px;top:591.3px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-orchestrator:01-sdlc</span></div>
  <div class="pptx-text" data-shape="8-14" style="left:89.1px;top:641.7px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Ajoute un DAG Airflow...</span></div>
  <div class="pptx-text" data-shape="8-15" style="left:81px;top:699.3px;width:667.8px;height:62.1px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">AIDD orchestre jusqu’à une PR/MR en brouillon, sans approbations systématiques.</span></div>
  <div class="pptx-text" data-shape="8-16" style="left:81px;top:772.2px;width:667.8px;height:33.3px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Pilotage : AIDD, avec les autorisations nécessaires.</span></div>
  <div class="pptx-text" data-shape="8-17" style="left:836.1px;top:503.1px;width:696.6px;height:70.2px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">4. SDLC INTERACTIF</span></div>
  <div class="pptx-text" data-shape="8-18" style="left:858.6px;top:591.3px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">/aidd-orchestrator:01-sdlc interactive</span></div>
  <div class="pptx-text" data-shape="8-19" style="left:858.6px;top:641.7px;width:651.6px;height:41.4px;padding:2.7px 2.7px;font-size:21.88px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Ajoute un DAG Airflow...</span></div>
  <div class="pptx-text" data-shape="8-20" style="left:850.5px;top:699.3px;width:667.8px;height:62.1px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Même orchestration, avec trois approbations : contrat, plan, résultat.</span></div>
  <div class="pptx-text" data-shape="8-21" style="left:850.5px;top:772.2px;width:667.8px;height:33.3px;padding:2.7px 2.7px;font-size:22.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Pilotage : AIDD, avec validations humaines.</span></div>
</div>

---

<!-- Diapositive 09 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-09.svg" alt="Fond vectoriel diapositive 9" />
  <div class="pptx-text" data-shape="9-1" style="left:69.3px;top:45.9px;width:1476px;height:71.1px;padding:2.7px 2.7px;font-size:50px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Le cycle de développement AIDD : Frame → Deliver → Check</span></div>
  <div class="pptx-text" data-shape="9-2" style="left:85.5px;top:204.3px;width:390.6px;height:46.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">1. FRAME — CADRER</span></div>
  <div class="pptx-text" data-shape="9-3" style="left:92.7px;top:293.4px;width:375.3px;height:126px;padding:2.7px 2.7px;font-size:24px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Qualifier la demande et produire
un contrat exploitable lorsque
nécessaire</span></div>
  <div class="pptx-text" data-shape="9-4" style="left:95.4px;top:469px;width:369.9px;height:93.6px;padding:2.7px 2.7px;font-size:26px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">« Qu’est-ce qui doit être
construit ? »</span></div>
  <div class="pptx-text" data-shape="9-5" style="left:83.7px;top:593.1px;width:393.3px;height:75.6px;padding:2.7px 2.7px;font-size:22px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Livrable :
contrat ou demande exploitable</span></div>
  <div class="pptx-text" data-shape="9-6" style="left:602.1px;top:204.3px;width:390.6px;height:46.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">2. DELIVER — RÉALISER</span></div>
  <div class="pptx-text" data-shape="9-7" style="left:609.3px;top:293.4px;width:375.3px;height:126px;padding:2.7px 2.7px;font-size:24px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Planifier, implémenter, vérifier et
préparer un candidat commité</span></div>
  <div class="pptx-text" data-shape="9-8" style="left:612px;top:469px;width:369.9px;height:93.6px;padding:2.7px 2.7px;font-size:26px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">« Comment construire et
vérifier la solution ? »</span></div>
  <div class="pptx-text" data-shape="9-9" style="left:599px;top:596px;width:397px;height:75.6px;padding:2.7px 2.7px;font-size:20.6px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Livrable :
candidat implémenté, vérifié et commité</span></div>
  <div class="pptx-text" data-shape="9-10" style="left:1118.7px;top:204.3px;width:390.6px;height:46.8px;padding:2.7px 2.7px;font-size:30px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">3. CHECK — CONTRÔLER</span></div>
  <div class="pptx-text" data-shape="9-11" style="left:1125.9px;top:293.4px;width:375.3px;height:126px;padding:2.7px 2.7px;font-size:24px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Valider indépendamment, faire
une revue et un challenge, puis
ouvrir une PR/MR en brouillon</span></div>
  <div class="pptx-text" data-shape="9-12" style="left:1128.6px;top:469px;width:369.9px;height:93.6px;padding:2.7px 2.7px;font-size:26px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">« Le résultat répond-il
au besoin et est-il fiable ? »</span></div>
  <div class="pptx-text" data-shape="9-13" style="left:1116.9px;top:593.1px;width:393.3px;height:75.6px;padding:2.7px 2.7px;font-size:22px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Livrable :
candidat revu et PR/MR brouillon</span></div>
  <div class="pptx-text" data-shape="9-14" style="left:342px;top:756px;width:981px;height:31.5px;padding:2.7px 2.7px;font-size:21.25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Des constats exploitables peuvent entraîner une reprise de Frame ou Deliver.</span></div>
  <div class="pptx-text" data-shape="9-15" style="left:234px;top:824px;width:1125px;height:38.7px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Les contrôles humains et techniques dépendent du mode et du contexte.</span></div>
</div>

---

<!-- Diapositive 10 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-10.svg" alt="Fond vectoriel diapositive 10" />
  <div class="pptx-text" data-shape="10-1" style="left:48.6px;top:36px;width:1512px;height:66.6px;padding:2.7px 2.7px;font-size:57.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Quels skills AIDD interviennent dans le SDLC ?</span></div>
  <div class="pptx-text" data-shape="10-2" style="left:59.4px;top:143.1px;width:465.3px;height:90px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">FRAME</span></div>
  <div class="pptx-text" data-shape="10-3" style="left:103.5px;top:265.5px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-pm:01-ticket-info</span></div>
  <div class="pptx-text" data-shape="10-4" style="left:103.5px;top:298.8px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">récupérer le ticket si nécessaire.</span></div>
  <div class="pptx-text" data-shape="10-5" style="left:103.5px;top:368.1px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-refine:01-brainstorm</span></div>
  <div class="pptx-text" data-shape="10-6" style="left:103.5px;top:401.4px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">lever les ambiguïtés.</span></div>
  <div class="pptx-text" data-shape="10-7" style="left:103.5px;top:470.7px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-pm:04-spec</span></div>
  <div class="pptx-text" data-shape="10-8" style="left:103.5px;top:504px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">formaliser le contrat si nécessaire.</span></div>
  <div class="pptx-text" data-shape="10-9" style="left:575.1px;top:143.1px;width:465.3px;height:90px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">DELIVER</span></div>
  <div class="pptx-text" data-shape="10-10" style="left:619.2px;top:265.5px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-dev:01-plan</span></div>
  <div class="pptx-text" data-shape="10-11" style="left:619.2px;top:298.8px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">planifier.</span></div>
  <div class="pptx-text" data-shape="10-12" style="left:619.2px;top:368.1px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-dev:02-implement</span></div>
  <div class="pptx-text" data-shape="10-13" style="left:619.2px;top:401.4px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">implémenter.</span></div>
  <div class="pptx-text" data-shape="10-14" style="left:619.2px;top:470.7px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-dev:03-assert</span></div>
  <div class="pptx-text" data-shape="10-15" style="left:619.2px;top:504px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">et tests adaptés : vérifier.</span></div>
  <div class="pptx-text" data-shape="10-16" style="left:619.2px;top:573.3px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-vcs:01-commit</span></div>
  <div class="pptx-text" data-shape="10-17" style="left:619.2px;top:606.6px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">enregistrer le candidat.</span></div>
  <div class="pptx-text" data-shape="10-18" style="left:1090.8px;top:143.1px;width:465.3px;height:90px;padding:2.7px 2.7px;font-size:40px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">CHECK</span></div>
  <div class="pptx-text" data-shape="10-19" style="left:1134.9px;top:265.5px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Sous-agent validator</span></div>
  <div class="pptx-text" data-shape="10-20" style="left:1134.9px;top:298.8px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">vérifier le contrat.</span></div>
  <div class="pptx-text" data-shape="10-21" style="left:1134.9px;top:366.3px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Sous-agent reviewer</span></div>
  <div class="pptx-text" data-shape="10-22" style="left:1134.9px;top:399.6px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">et aidd-dev:05-review : examiner le résultat.</span></div>
  <div class="pptx-text" data-shape="10-23" style="left:1134.9px;top:467.1px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-refine:02-challenge</span></div>
  <div class="pptx-text" data-shape="10-24" style="left:1134.9px;top:500.4px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">remettre le résultat en question.</span></div>
  <div class="pptx-text" data-shape="10-25" style="left:1134.9px;top:567.9px;width:405.9px;height:29.7px;padding:2.7px 2.7px;font-size:27.75px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">aidd-vcs:02-pull-request</span></div>
  <div class="pptx-text" data-shape="10-26" style="left:1134.9px;top:601.2px;width:405.9px;height:63.9px;padding:2.7px 2.7px;font-size:23.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">ouvrir une PR/MR brouillon.</span></div>
  <div class="pptx-text" data-shape="10-27" style="left:59.4px;top:722.7px;width:1471.5px;height:98.1px;padding:2.7px 2.7px;font-size:35px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Les skills sont appelés automatiquement par l’orchestrateur SDLC.</span></div>
</div>

---

<!-- Diapositive 11 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-11.svg" alt="Fond vectoriel diapositive 11" />
  <div class="pptx-text" data-shape="11-1" style="left:58.5px;top:41.4px;width:1485px;height:63px;padding:2.7px 2.7px;font-size:47.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Articulation des connaissances : Mémoire, Règles et Cartulary</span></div>
  <div class="pptx-text" data-shape="11-2" style="left:76.5px;top:183.6px;width:655.2px;height:55.8px;padding:2.7px 2.7px;font-size:32.5px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Définitions :</span></div>
  <div class="pptx-text" data-shape="11-3" style="left:122.4px;top:259.2px;width:591.3px;height:72.9px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Mémoire AIDD : Connaissances durables
du projet.</span></div>
  <div class="pptx-text" data-shape="11-4" style="left:122.4px;top:334.8px;width:591.3px;height:72.9px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Règles et ADR : Contraintes, conventions
et décisions d’architecture.</span></div>
  <div class="pptx-text" data-shape="11-5" style="left:122.4px;top:410.4px;width:591.3px;height:72.9px;padding:2.7px 2.7px;font-size:26.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Cartulary : Outil externe envisagé pour
gérer des règles et ADR.</span></div>
  <div class="pptx-text" data-shape="11-6" style="left:834.3px;top:187.2px;width:301.5px;height:60.3px;padding:2.7px 2.7px;font-size:25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:center;font-style:normal"><span class="pptx-txt-inner">[ Mémoire projet AIDD ]</span></div>
  <div class="pptx-text" data-shape="11-7" style="left:1235.7px;top:197.1px;width:289.8px;height:39.6px;padding:2.7px 2.7px;font-size:22.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Cartulary (externe) ]</span></div>
  <div class="pptx-text" data-shape="11-8" style="left:1235.7px;top:330.3px;width:283.5px;height:40.5px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Skill de sélection ]</span></div>
  <div class="pptx-text" data-shape="11-9" style="left:850.5px;top:468px;width:278.1px;height:43.2px;padding:2.7px 2.7px;font-size:24px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Contexte de l’assistant IA ]</span></div>
  <div class="pptx-text" data-shape="11-10" style="left:1251px;top:469.8px;width:252px;height:36px;padding:2.7px 2.7px;font-size:25px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">[ Workflow AIDD ]</span></div>
  <div class="pptx-text" data-shape="11-11" style="left:76.5px;top:592.2px;width:1449px;height:53.1px;padding:2.7px 2.7px;font-size:31.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:left;justify-content:center;font-style:normal"><span class="pptx-txt-inner">Comportements à définir et tester :</span></div>
  <div class="pptx-text" data-shape="11-12" style="left:120.6px;top:668.7px;width:1380.6px;height:47.7px;padding:2.7px 2.7px;font-size:24.38px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Conflit : comment une règle spécifiquement chargée prime sur la mémoire générale.</span></div>
  <div class="pptx-text" data-shape="11-13" style="left:120.6px;top:719.1px;width:1380.6px;height:47.7px;padding:2.7px 2.7px;font-size:24.38px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Volume : impact du chargement conditionnel sur la consommation de tokens.</span></div>
  <div class="pptx-text" data-shape="11-14" style="left:120.6px;top:773px;width:1380.6px;height:47.7px;padding:2.7px 2.7px;font-size:24.38px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Dégradation : comportement en cas d’indisponibilité de Cartulary.</span></div>
</div>

---

<!-- Diapositive 12 : HTML/SVG intégralement éditable dans Slidev -->
<div class="pptx-canvas scenario-aidd">
  <div class="sc-title">Scénario concret : ajout d’un DAG Airflow Python et d’une configuration Terraform</div>

  <div class="sc-lane" style="top:110px;height:244px;background:#D9ECF8"></div>
  <div class="sc-lane" style="top:378px;height:205px;background:#FBE8D7"></div>
  <div class="sc-lane" style="top:610px;height:187px;background:#ECEFF2"></div>
  <div class="sc-tag sc-tag-ai">Actions de l’assistant IA</div>
  <div class="sc-tag sc-tag-human">Validations de l’ingénieur</div>
  <div class="sc-tag sc-tag-ci">Contrôles de CI</div>

  <svg class="sc-arrows" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" aria-hidden="true">
    <defs><marker id="sc-head" markerWidth="11" markerHeight="11" refX="9" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10" fill="none" stroke="#20394F" stroke-width="2"/></marker></defs>
    <g fill="none" stroke="#20394F" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#sc-head)">
      <path d="M339 490 L364 490 L364 244 L412 244"/>
      <path d="M673 239 L754 239" stroke-dasharray="7 7"/>
      <path d="M547 299 L547 439"/>
      <path d="M699 487 L727 487 L727 295 L757 295"/>
      <path d="M923 306 L923 654"/>
      <path d="M1063 663 L1063 507 L1096 507"/>
      <path d="M1255 488 L1265 488 L1265 236 L1276 236"/>
      <path d="M1391 301 L1391 440"/>
    </g>
  </svg>
  <div class="sc-mode-auto">Automatique : pas de pause</div>

  <div class="sc-card sc-blue" style="left:408px;top:174px;width:265px;height:126px">
    <strong>Analyse &amp; planification</strong><span><code>plan_dag.md</code><br/>Contexte &amp; règles</span>
  </div>
  <div class="sc-card sc-blue" style="left:755px;top:174px;width:335px;height:126px">
    <strong>Implémentation</strong><span><code>dags/ingestion_dag.py</code><br/><code>tests/test_ingestion_dag.py</code><br/><code>infra/main.tf</code></span>
  </div>
  <div class="sc-card sc-blue" style="left:1276px;top:174px;width:251px;height:126px">
    <strong>MR en brouillon</strong><span>Créée sur GitLab</span>
  </div>

  <div class="sc-card sc-peach" style="left:61px;top:435px;width:279px;height:113px">
    <strong>Besoin et critères</strong><span><code>ticket_airflow.md</code></span>
  </div>
  <div class="sc-card sc-peach" style="left:408px;top:440px;width:291px;height:108px">
    <strong>Approbation du plan</strong><span>Mode interactif uniquement</span>
  </div>
  <div class="sc-card sc-peach" style="left:1096px;top:440px;width:159px;height:108px">
    <strong>Revue de code</strong><span>et tests</span>
  </div>
  <div class="sc-card sc-peach" style="left:1301px;top:440px;width:221px;height:108px">
    <strong>Revue finale</strong><span>et fusion</span>
  </div>

  <div class="sc-card sc-grey" style="left:765px;top:663px;width:430px;height:102px">
    <strong>Contrôles automatisés</strong><span><code>pytest</code> · <code>terraform fmt -check</code><br/><code>terraform validate</code></span>
  </div>
  <div class="sc-footnote">Les approbations intermédiaires dépendent du mode SDLC. Les contrôles techniques et la revue avant fusion restent applicables.</div>
</div>

---

<!-- Diapositive 13 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-13.svg" alt="Fond vectoriel diapositive 13" />
  <div class="pptx-text" data-shape="13-1" style="left:97.2px;top:125.1px;width:637.2px;height:101.7px;padding:2.7px 2.7px;font-size:36.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">1. Mémoire projet fiable</span></div>
  <div class="pptx-text" data-shape="13-2" style="left:99px;top:240.3px;width:630px;height:162.9px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Précaution concrète : maintenir le dossier
`aidd_docs/memory/` propre. Contrôler
les changements de l’IA sur ces fichiers
pour éviter les dérives.</span></div>
  <div class="pptx-text" data-shape="13-3" style="left:866.7px;top:125.1px;width:637.2px;height:101.7px;padding:2.7px 2.7px;font-size:36.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">2. Validation humaine et CI
adaptées au risque</span></div>
  <div class="pptx-text" data-shape="13-4" style="left:868.5px;top:240.3px;width:630px;height:162.9px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Précaution concrète : revue humaine
des PR/MR, particulièrement critique
pour l’Infrastructure as Code.
L’automatisation n’exclut pas la responsabilité.</span></div>
  <div class="pptx-text" data-shape="13-5" style="left:97.2px;top:503.1px;width:637.2px;height:101.7px;padding:2.7px 2.7px;font-size:36.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">3. Maîtrise du contexte et des
données communiquées au LLM</span></div>
  <div class="pptx-text" data-shape="13-6" style="left:99px;top:618.3px;width:630px;height:162.9px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Précaution concrète : limiter le périmètre
transmis à l’IA pour préserver le contexte.
La télémétrie AIDD est optionnelle
et dépend de l’assistant utilisé.</span></div>
  <div class="pptx-text" data-shape="13-7" style="left:866.7px;top:503.1px;width:637.2px;height:101.7px;padding:2.7px 2.7px;font-size:36.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">4. Sécurité des scripts et hooks</span></div>
  <div class="pptx-text" data-shape="13-8" style="left:868.5px;top:618.3px;width:630px;height:162.9px;padding:2.7px 2.7px;font-size:28.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Les hooks et scripts peuvent exécuter des
contrôles automatisés. Vérifier leur provenance,
leurs permissions et leurs opérations.
Protéger les accès réseau et services externes.</span></div>
</div>

---

<!-- Diapositive 14 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-14.svg" alt="Fond vectoriel diapositive 14" />
  <div class="pptx-text" data-shape="14-1" style="left:76.5px;top:54px;width:1449px;height:68.4px;padding:2.7px 2.7px;font-size:52.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Skills ponctuels : intervenir sans relancer tout le SDLC</span></div>
  <div class="pptx-text" data-shape="14-2" style="left:114.3px;top:190.8px;width:1367.1px;height:82.8px;padding:2.7px 2.7px;font-size:28.75px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#FFFFFF;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Lorsqu’un SDLC complet est utilisé, AIDD orchestre planification, implémentation,
validations, commits et PR/MR. Il n’est pas nécessaire de relancer ces skills.</span></div>
  <div class="pptx-text" data-shape="14-3" style="left:103.5px;top:351.9px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">1. Planifier</span></div>
  <div class="pptx-text" data-shape="14-4" style="left:108px;top:410.4px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:01-plan</span></div>
  <div class="pptx-text" data-shape="14-5" style="left:108.9px;top:465.3px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Préparer un plan pour une
modification étudiée isolément.</span></div>
  <div class="pptx-text" data-shape="14-6" style="left:601.2px;top:351.9px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">2. Auditer</span></div>
  <div class="pptx-text" data-shape="14-7" style="left:605.7px;top:410.4px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:04-audit</span></div>
  <div class="pptx-text" data-shape="14-8" style="left:606.6px;top:465.3px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Examiner la qualité, la sécurité
ou l’architecture du projet.</span></div>
  <div class="pptx-text" data-shape="14-9" style="left:1098.9px;top:351.9px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">3. Faire une revue</span></div>
  <div class="pptx-text" data-shape="14-10" style="left:1103.4px;top:410.4px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:05-review</span></div>
  <div class="pptx-text" data-shape="14-11" style="left:1104.3px;top:465.3px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Examiner un diff ou des
modifications existantes.</span></div>
  <div class="pptx-text" data-shape="14-12" style="left:103.5px;top:593.1px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">4. Déboguer</span></div>
  <div class="pptx-text" data-shape="14-13" style="left:108px;top:651.6px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-dev:08-debug</span></div>
  <div class="pptx-text" data-shape="14-14" style="left:108.9px;top:706.5px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Reproduire et corriger un bug
précis.</span></div>
  <div class="pptx-text" data-shape="14-15" style="left:601.2px;top:593.1px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">5. Capitaliser</span></div>
  <div class="pptx-text" data-shape="14-16" style="left:605.7px;top:651.6px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-context:10-learn</span></div>
  <div class="pptx-text" data-shape="14-17" style="left:606.6px;top:706.5px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Enregistrer une décision, une
convention ou une leçon durable.</span></div>
  <div class="pptx-text" data-shape="14-18" style="left:1098.9px;top:593.1px;width:417.6px;height:39.6px;padding:2.7px 2.7px;font-size:32.5px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">6. Créer un commit</span></div>
  <div class="pptx-text" data-shape="14-19" style="left:1103.4px;top:651.6px;width:406.8px;height:28.8px;padding:2.7px 2.7px;font-size:23.75px;font-weight:400;font-family:'DejaVu Sans Mono',Inter,Arial,sans-serif;color:#192F46;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">/aidd-vcs:01-commit</span></div>
  <div class="pptx-text" data-shape="14-20" style="left:1104.3px;top:706.5px;width:406.8px;height:67.5px;padding:2.7px 2.7px;font-size:23.12px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Créer un commit atomique hors
du SDLC complet.</span></div>
</div>

---

<!-- Diapositive 15 : contenu éditable directement dans les divs HTML ci-dessous -->
<div class="pptx-canvas">
  <img class="pptx-vector-bg" src="/art/slide-15.svg" alt="Fond vectoriel diapositive 15" />
  <div class="pptx-text" data-shape="15-1" style="left:58.5px;top:47.7px;width:1449px;height:76.5px;padding:2.7px 2.7px;font-size:62.5px;font-weight:700;font-family:'Inter Display',Inter,Arial,sans-serif;color:#192F46;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Synthèse &amp; Posture d’Ingénierie</span></div>
  <div class="pptx-text" data-shape="15-2" style="left:71.1px;top:182.7px;width:119.7px;height:72px;padding:2.7px 2.7px;font-size:55px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#A06C4F;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">◇</span></div>
  <div class="pptx-text" data-shape="15-3" style="left:202.5px;top:188.1px;width:1317.6px;height:88.2px;padding:2.7px 2.7px;font-size:35px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">AIDD structure les workflows de développement assisté par IA.</span></div>
  <div class="pptx-text" data-shape="15-4" style="left:71.1px;top:306.9px;width:119.7px;height:72px;padding:2.7px 2.7px;font-size:55px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#A06C4F;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">♙</span></div>
  <div class="pptx-text" data-shape="15-5" style="left:202.5px;top:312.3px;width:1317.6px;height:88.2px;padding:2.7px 2.7px;font-size:35px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">L’ingénieur conserve la responsabilité du résultat et des contrôles
appropriés.</span></div>
  <div class="pptx-text" data-shape="15-6" style="left:71.1px;top:431.1px;width:119.7px;height:72px;padding:2.7px 2.7px;font-size:55px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#A06C4F;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">▤</span></div>
  <div class="pptx-text" data-shape="15-7" style="left:202.5px;top:436.5px;width:1317.6px;height:88.2px;padding:2.7px 2.7px;font-size:35px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">La mémoire projet, les règles de développement, les tests et la CI
complètent ces workflows.</span></div>
  <div class="pptx-text" data-shape="15-8" style="left:81.9px;top:608.4px;width:720px;height:38.7px;padding:2.7px 2.7px;font-size:31.25px;font-weight:700;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Pour aller plus loin</span></div>
  <div class="pptx-text" data-shape="15-9" style="left:96.3px;top:657.9px;width:364.5px;height:35.1px;padding:2.7px 2.7px;font-size:21.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">• Dépôt officiel AIDD :</span></div>
  <div class="pptx-text" data-shape="15-10" style="left:446.4px;top:657.9px;width:1060.2px;height:32.4px;padding:2.7px 2.7px;font-size:19.62px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">https://github.com/ai-driven-dev/framework</span></div>
  <div class="pptx-text" data-shape="15-11" style="left:96.3px;top:694.8px;width:364.5px;height:35.1px;padding:2.7px 2.7px;font-size:21.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">• Documentation d’installation :</span></div>
  <div class="pptx-text" data-shape="15-12" style="left:446.4px;top:694.8px;width:1060.2px;height:32.4px;padding:2.7px 2.7px;font-size:19.62px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">https://github.com/ai-driven-dev/framework/blob/main/docs/INSTALL.md</span></div>
  <div class="pptx-text" data-shape="15-13" style="left:96.3px;top:731.7px;width:364.5px;height:35.1px;padding:2.7px 2.7px;font-size:21.88px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">• Catalogue des skills :</span></div>
  <div class="pptx-text" data-shape="15-14" style="left:446.4px;top:731.7px;width:1060.2px;height:32.4px;padding:2.7px 2.7px;font-size:19.62px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#186C78;text-align:left;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">https://github.com/ai-driven-dev/framework/blob/main/docs/CATALOG.md</span></div>
  <div class="pptx-text" data-shape="15-15" style="left:76.5px;top:801.9px;width:1444.5px;height:67.5px;padding:2.7px 2.7px;font-size:24.38px;font-weight:400;font-family:'Inter',Inter,Arial,sans-serif;color:#1D2327;text-align:center;justify-content:flex-start;font-style:normal"><span class="pptx-txt-inner">Les mécanismes Makefile et l’intégration envisagée avec Cartulary sont des adaptations possibles
à un environnement, et non des fonctionnalités natives garanties par AIDD.</span></div>
</div>
