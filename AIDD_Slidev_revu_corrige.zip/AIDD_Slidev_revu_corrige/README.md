# AIDD — présentation Slidev éditable, revue et corrigée (15 diapositives)

Conversion depuis `AIDD_V11_PowerPoint_reconstruit_editable.pptx`. La charte graphique (ivoire, bleu nuit, bleu pétrole et cuivre) et la géométrie d'origine sont reprises au plus près.

## Démarrer

```bash
npm install
npm run dev
```

Ouvrir l'URL affichée par Slidev pour présenter la présentation. Utiliser les flèches pour naviguer.

## Modifier le contenu

- **Textes, commandes AIDD et libellés** : modifier les éléments `<div class="pptx-text">` de `slides.md`.
- **Schémas, cadres, connecteurs, couleur de fond** : fichiers SVG vectoriels indépendants dans `public/art/slide-XX.svg` (modifiables en SVG, par ex. Inkscape, ou par leur source).
- **Couleurs, typographie et mise en page générale** : `style.css`.
- **Ajouter une diapositive** : insérer un séparateur `---` dans `slides.md` et écrire du Markdown/HTML Slidev.

## Construire et exporter

```bash
npm run build
npm run export
```

## Fidélité et limites

- Ce n'est pas une suite de captures d'écran. Les textes sont **sélectionnables** et les éléments de dessin sont **vectoriels**.
- La conversion cherche à reproduire **le PowerPoint reconstruit éditable**, qui est lui-même une adaptation du PDF NotebookLM ; certains pictogrammes ou espacements diffèrent donc du PDF original.
- Les textes sont positionnés en HTML absolu pour conserver la géométrie ; les réorganisations profondes demanderont un ajustement des coordonnées ou une réécriture de la diapositive en Markdown natif.
- Les polices `Inter Display` et `Inter` doivent être présentes pour une fidélité optimale ; à défaut, Arial est utilisé. Aucune police n'est distribuée ici.

La **diapositive 12** est reconstruite avec un layout Slidev en HTML/CSS + SVG natif dans `slides.md`, pour éviter les chevauchements de texte de la conversion géométrique.


## Revue de mise en page (17 novembre 2026)

- Diapositive 7 : chevrons et pictogrammes refaits en HTML/SVG vectoriel avec des numéros lisibles et des espaces réguliers.
- Diapositive 9 : boucle de retour SDLC rétablie et textes de livrable/rappel réespacés.
- Diapositive 12 : connecteurs entre les vérifications, la revue et l'ouverture de MR reroutés pour ne plus passer sur les libellés.
- Diapositive 11 : légère correction d'alignement dans les points d'attention.
- Les 15 diapositives conservent leurs textes et formes modifiables.

**Vérification de rendu :** aperçus HTML/CSS/SVG à 1600 × 900 et contrôle visuel des 15 pages. L'environnement de génération ne permet pas d'installer `@slidev/cli` depuis npm ; le lancement complet dans Slidev n'a donc pas été validé ici. Après `npm install`, vérifier la projection et l'export avec `npm run build` / `npm run export`.
